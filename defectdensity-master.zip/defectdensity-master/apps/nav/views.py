from django.shortcuts import render
from django.views.generic.base import View

from .models import DashboardNav, GrafanaNav

# Create your views here.


class IndexView(View):
    def get(self, request):
        return render(request, "index.html")


class ElkView(View):
    def get(self, request):
        return render(request, "elk.html")


class DashboardView(View):   # 首页
    def get(self, request):
        categorys = DashboardNav.objects.values("category").distinct()
        category_info_list = []
        for category_item in categorys:
            category_info_list.append((category_item['category'], DashboardNav.objects.filter(category=category_item['category'])))
        print(category_info_list)
        return render(request, "dashboard.html", {"category_info_list": category_info_list})


class GrafanaView(View):  # grafana相关列表
    def get(self, request):
        projects = GrafanaNav.objects.values("project_name").distinct()
        project_info_list = []
        for project_item in projects:
            categorys = GrafanaNav.objects.filter(project_name=project_item['project_name']).values("category").distinct()
            category_info_list = []
            for category_item in categorys:
                category_info_list.append(
                    (
                        category_item['category'],
                        GrafanaNav.objects.filter(category=category_item['category'], project_name=project_item['project_name'])
                    )
                )
            print(category_info_list)
            project_info_list.append((project_item['project_name'], category_info_list))
        print(project_info_list)
        return render(request, "grafana.html", {"project_info_list": project_info_list})
