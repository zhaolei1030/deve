from django.apps import AppConfig


class NavConfig(AppConfig):
    name = 'apps.nav'
