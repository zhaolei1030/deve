from django.db import models

# Create your models here.


class DashboardNav(models.Model):
    """
    首页 - 导航信息
    """
    category = models.CharField(max_length=128, verbose_name="大分类")
    department = models.CharField(max_length=128, verbose_name="部门")
    use = models.CharField(max_length=128, verbose_name="作用")
    image = models.CharField(max_length=256, verbose_name="封面")
    url = models.CharField(max_length=256, verbose_name="链接地址")

    class Meta:
        verbose_name = "首页 - 导航信息"
        verbose_name_plural = verbose_name

    def __str__(self):
        return "{} - {}".format(self.category, self.use)


class GrafanaNav(models.Model):
    """
    Grafana - 导航信息
    """
    project_name = models.CharField(max_length=128, verbose_name="项目名")
    hostname = models.CharField(max_length=128, verbose_name="主机名")
    ip = models.CharField(max_length=128, verbose_name="主机IP")
    image = models.CharField(max_length=256, verbose_name="封面")
    url = models.CharField(max_length=256, verbose_name="链接地址")
    category = models.CharField(max_length=128, verbose_name="分类")
    env = models.CharField(max_length=128, verbose_name="环境")
    desc = models.CharField(max_length=128, verbose_name="描述信息", null=True, blank=True)

    class Meta:
        verbose_name = "Grafana - 导航信息"
        verbose_name_plural = verbose_name

    def __str__(self):
        return "{} - {}".format(self.project_name, self.hostname)
