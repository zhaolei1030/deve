import xadmin

from .models import DashboardNav, GrafanaNav


class DashboardNavAdmin(object):
    list_display = ['category', 'department', 'use', 'image', 'url']
    search_fields = ['category', 'department', 'use', 'image', 'url']
    list_filter = ['category', 'department', 'use', 'image', 'url']


class GrafanaNavAdmin(object):
    list_display = ['project_name', 'hostname', 'ip', 'image', 'env','url','category','desc']
    search_fields = ['project_name', 'hostname', 'ip', 'image', 'env','url','category','desc']
    list_filter = ['project_name', 'hostname', 'ip', 'image', 'env','url','category','desc']


xadmin.site.register(DashboardNav, DashboardNavAdmin)
xadmin.site.register(GrafanaNav, GrafanaNavAdmin)
