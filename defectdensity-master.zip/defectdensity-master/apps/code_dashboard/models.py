from django.db import models

# Create your models here.


class GitlabRepo(models.Model):
    url = models.CharField(max_length=128, verbose_name="gitlab url地址")
    path = models.CharField(max_length=128, verbose_name="代码路径")
    private_token = models.CharField(max_length=128, verbose_name="个人私钥")
    branch = models.CharField(max_length=64, verbose_name="代码分支")
    project_num = models.CharField(max_length=64, verbose_name="项目ID（禅道）")
    project_name = models.CharField(max_length=64, verbose_name="项目名称（禅道）")

    class Meta:
        verbose_name = "Gitlab Repo信息"
        verbose_name_plural = verbose_name
        # unique_together = ("path", "branch")

    def __str__(self):
        return "{} - {}".format(self.path, self.branch)


class CommitInfo(models.Model):
    commit_id = models.CharField(max_length=256, verbose_name="Commit ID")
    commit_time = models.DateTimeField(verbose_name="commit 时间")
    change_lines = models.IntegerField(verbose_name="改变行数")
    gitlab_repo = models.ForeignKey(GitlabRepo, verbose_name="gitlab repo", on_delete=models.CASCADE)

    class Meta:
        verbose_name = "Repo commit信息"
        verbose_name_plural = verbose_name

    def __str__(self):
        return "{} - {}".format(self.gitlab_repo.path, self.commit_id)


class CommitSummary(models.Model):
    from_date = models.DateField(verbose_name="开始日期")
    to_date = models.DateField(verbose_name="结束日期")
    gitlab_repo = models.ForeignKey(GitlabRepo, verbose_name="gitlab repo", on_delete=models.CASCADE)
    total = models.IntegerField(verbose_name="本周改变行数")
    date_point = models.DateField(verbose_name="日期打点")
    defect_density = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="缺陷密度")

    class Meta:
        verbose_name = "Repo commit汇总信息"
        verbose_name_plural = verbose_name

    def __str__(self):
        return "{} - {}".format(self.gitlab_repo.path, self.date_point)


class ZendaoBugSummary(models.Model):
    gitlab_repo = models.ForeignKey(GitlabRepo, verbose_name="gitlab repo", on_delete=models.CASCADE)
    last = models.IntegerField(verbose_name="遗留BUG", default=0)
    online = models.IntegerField(verbose_name="线上反馈", default=0)
    codeerror = models.IntegerField(verbose_name="代码错误", default=0)
    interface = models.IntegerField(verbose_name="界面优化", default=0)
    config = models.IntegerField(verbose_name="配置问题", default=0)
    install = models.IntegerField(verbose_name="安装部署", default=0)
    security = models.IntegerField(verbose_name="安全相关", default=0)
    performance = models.IntegerField(verbose_name="性能问题", default=0)
    standard = models.IntegerField(verbose_name="标准规范", default=0)
    automation = models.IntegerField(verbose_name="测试脚本", default=0)
    designdefect = models.IntegerField(verbose_name="设计缺陷", default=0)
    codeimprovement = models.IntegerField(verbose_name="代码改进", default=0)
    others = models.IntegerField(verbose_name="其他", default=0)
    requrement = models.IntegerField(verbose_name="需求变更", default=0)
    prodissue = models.IntegerField(verbose_name="线上BUG", default=0)
    prodissue1 = models.IntegerField(verbose_name="线上BUG（建议）数量", default=0)
    prodissue2 = models.IntegerField(verbose_name="线上BUG（一般）数量", default=0)
    prodissue3 = models.IntegerField(verbose_name="线上BUG（重要）数量", default=0)
    prodissue4 = models.IntegerField(verbose_name="线上BUG（指明）数量", default=0)
    reopen = models.IntegerField(verbose_name="修复后重现", default=0)
    autodetected = models.IntegerField(verbose_name="自动化发现", default=0)
    envissue = models.IntegerField(verbose_name="环境问题", default=0)
    total = models.IntegerField(verbose_name="总数", default=0)
    date_point = models.DateField(verbose_name="日期打点")

    class Meta:
        verbose_name = "Zendao Bug汇总信息"
        verbose_name_plural = verbose_name

    def __str__(self):
        return "{} - {}".format(self.gitlab_repo.path, self.date_point)

