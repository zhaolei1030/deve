import xadmin

from .models import GitlabRepo, CommitInfo, CommitSummary, ZendaoBugSummary


class GitlabRepoAdmin(object):
    list_display = ['url', 'path', 'branch', 'project_name']
    search_fields = ['url', 'path', 'branch', 'project_name']
    list_filter = ['url', 'path', 'branch']


class CommitInfoInfoAdmin(object):
    list_display = ['commit_id',  'change_lines', 'gitlab_repo','commit_time']
    search_fields = ['commit_id',  'change_lines', 'gitlab_repo']
    list_filter = ['commit_id',  'change_lines', 'gitlab_repo','commit_time']


class CommitSummaryAdmin(object):
    list_display = ['from_date', 'to_date', 'gitlab_repo', 'total']
    search_fields = ['build_count', 'gitlab_repo', 'total']
    list_filter = ['from_date', 'to_date', 'gitlab_repo', 'total']


class ZendaoBugSummaryAdmin(object):
    list_display = ['gitlab_repo', 'total', 'date_point']
    search_fields = ['gitlab_repo', 'total', 'date_point']
    list_filter = ['gitlab_repo', 'total', 'date_point']

xadmin.site.register(GitlabRepo, GitlabRepoAdmin)
xadmin.site.register(CommitInfo, CommitInfoInfoAdmin)
xadmin.site.register(CommitSummary, CommitSummaryAdmin)
xadmin.site.register(ZendaoBugSummary, ZendaoBugSummaryAdmin)
