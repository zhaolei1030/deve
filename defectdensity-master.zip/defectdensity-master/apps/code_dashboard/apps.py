from django.apps import AppConfig


class CodeDashboardConfig(AppConfig):
    name = 'code_dashboard'
