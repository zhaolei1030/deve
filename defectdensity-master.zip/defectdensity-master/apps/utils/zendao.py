import requests
import json
from datetime import datetime,timedelta


class ZentaoBugWeight():  #
    def __init__(self, url, account, password, pro_num):
        self.url = url
        self.account = account
        self.password = password
        self.pro_num = pro_num

    def get_data(self):
        """
        登录cd
        :return:
        """
        session = requests.session()
        path = '/pro/user-login.html'
        session.post(url=self.url + path, data={"account": self.account, "password": self.password})
        path = '/pro/bug-browse-%s-0-all-opendate_desc--1-2-1.json' % (self.pro_num)
        print(self.url + path)
        content = session.get(url=self.url + path)
        print(content.text)
        path = '/pro/project-index.json'
        project = session.get(url=self.url + path)
        return content, project

    def parser(self, content, project,  project_name, start_day=None, end_day=None):
        """
        对网页内容分别解析
        :param content:
        :param project:
        :param project_name:
        :param start_day:
        :param end_day:
        :return: 各个任务的权重
        """
        if not start_day or not end_day:
            now = datetime.now()
            today = datetime(now.year, now.month, now.day, 0, 0, 0)

            # 本周
            start_day = today - timedelta(days=today.weekday())  # 周一0点
            end_day = today + timedelta(days=6 - today.weekday())  # 周日0点
            start_day = start_day.strftime('%Y-%m-%d')
            end_day = end_day.strftime('%Y-%m-%d')
        if type(start_day) == datetime:
            start_day = start_day.strftime('%Y-%m-%d')
        if type(end_day) == datetime:
            end_day = end_day.strftime('%Y-%m-%d')

        # 解析bug列表
        content = content.text
        content = json.loads(content)
        content = json.dumps(content).encode('utf-8').decode('unicode_escape')
        a = content.find('"bugs"')
        b = content.find('"users"')
        content = content[a:b]
        content = content[8:-2]
        content = content.replace('null', '"null"')
        content = content.replace('false', 'False')
        content = content.replace('\n', '')

        # 去掉title,steps字段
        while (1):
            a = content.find('\"title')
            b = content.find('\",\"keywords')
            if a == -1 or b == -1:
                break
            content = content[:a] + content[b + 1:]
        content = content.replace(',,', ',')

        while (1):
            a = content.find('\"steps')
            b = content.find('\",\"status')
            if a == -1 or b == -1:
                break
            content = content[:a] + content[b + 1:]
        content = content.replace(',,', ',')

        data = eval(content)

        # 解析项目列表
        project = project.text
        project = json.loads(project)
        project = json.dumps(project).encode('utf-8').decode('unicode_escape')
        a = project.find('"projects"')
        b = project.find('"project"')
        project = project[a:b]
        project = project[11:-1]
        project = eval(project)

        # 不同分支的bug加权
        result = {project_name:0}
        weight = {1: 4, 2: 3, 3: 2, 4: 1, 5: 5}
        for item in data:
            if item['openedDate'] < end_day + ' 23:59:59':
                if item['openedDate'] < start_day + ' 00:00:00':
                    break
        return result[project_name]


class ZentaoBugCounter():
    def __init__(self, url, account, password, pro_num):
        self.url = url
        self.account = account
        self.password = password
        self.pro_num = pro_num

    def get_data(self):
        """
        获取api数据
        :return:
        """
        session = requests.session()
        path = '/pro/user-login.html'
        session.post(url=self.url + path, data={"account": self.account, "password": self.password})
        path = '/pro/api-getsessionid.json'
        content = session.get(url=self.url + path)
        print(content)
        try:
            session_id = content.json()
        except Exception as e:
            print(self.pro_num)
            return None
        temp = session_id['data']
        temp = json.loads(temp)
        session_id = temp['sessionID']
        path = '/pro/bug-browse-%s-0-all-opendate_desc--1-2-1.json' % (self.pro_num)
        print('this is path')
        print(path)
        content = session.get(url=self.url + path)
        path = '/pro/project-index.json?zentaosid=%s' % (session_id)
        project = session.get(url=self.url + path)
        return content, project

    def handle(self, item, distribution):
        """
        对bug的级别进行统计
        :param item:
        :param distribution:
        :return:
        """
        if item['type'] in distribution:
            distribution[item['type']] += 1
            distribution['total'] += 1
            if item['type'] == "prodissue":
                if item['severity'] == 4:
                    distribution['prodissue1'] += 1
                elif item['severity'] == 3:
                    distribution['prodissue2'] += 1
                elif item['severity'] == 2:
                    distribution['prodissue3'] += 1
                elif item['severity'] == 1:
                    distribution['prodissue4'] += 1
                elif item['severity'] == 5:
                    distribution['prodissue5'] += 1
        return distribution

    def parser(self, content, project, project_name, start_day=None, end_day=None):
        if not start_day or not end_day:
            now = datetime.now()
            today = datetime(now.year, now.month, now.day, 0, 0, 0)

            # 本周
            start_day = today - timedelta(days=today.weekday())  # 周一0点
            end_day = today + timedelta(days=6 - today.weekday())  # 周日0点
            start_day = start_day.strftime('%Y-%m-%d')
            end_day = end_day.strftime('%Y-%m-%d')
        if type(start_day) == datetime:
            start_day = start_day.strftime('%Y-%m-%d')
        if type(end_day) == datetime:
            end_day = end_day.strftime('%Y-%m-%d')

        # 解析bug列表
        content = content.text
        print(type(content))
        # content = content.replace('\\','\\\\')
        content = json.loads(content)
        # content = {k: v.replace('\\\\', '\\') for k, v in content.items()}
        content = json.dumps(content).encode('utf-8').decode('unicode_escape')
        a = content.find('"bugs"')
        b = content.find('"users"')
        content = content[a:b]
        content = content[8:-2]
        content = content.replace('false', 'False')
        content = content.replace('null', '"null"')

        # 去掉title,steps字段
        while (1):
            a = content.find('\"title')
            b = content.find('\",\"keywords')
            if a == -1 or b == -1:
                break
            content = content[:a] + content[b + 1:]
        content = content.replace(',,', ',')

        while (1):
            a = content.find('\"steps')
            b = content.find('\",\"status')
            if a == -1 or b == -1:
                break
            content = content[:a] + content[b + 1:]
        content = content.replace(',,', ',')

        data = eval(content)

        # 解析项目列表
        try:
            project = project.text
            project = json.loads(project)
            project = json.dumps(project).encode('utf-8').decode('unicode_escape')
        except Exception:
            print(project_name, "JSON Exception")
        # print(project)
        a = project.find('"projects"')
        b = project.find('"project"')
        project = project[a:b]
        project = project[11:-1]
        project = eval(project)

        # 不同类别的bug计数
        distribution = {
            'last': 0,
            'online': 0,
            'codeerror': 0,
            'interface': 0,
            'config': 0,
            'install': 0,
            'security': 0,
            'performance': 0,
            'standard': 0,
            'automation': 0,
            'designdefect': 0,
            'codeimprovement': 0,
            'others': 0,
            'requrement': 0,
            'prodissue': 0,
            'prodissue1': 0,
            'prodissue2': 0,
            'prodissue3': 0,
            'prodissue4': 0,
            'reopen': 0,
            'autodetected': 0,
            'envissue': 0,
            'total': 0
        }

        for item in data:
            if item['openedDate'] < end_day + ' 23:59:59':
                if item['openedDate'] < start_day + ' 00:00:00':
                    break
        return distribution


if __name__ == "__main__":
    zendao_bug_counter = ZentaoBugCounter('http://xxx.xxx.com', 'xxxxxx', 'xxxx', 'xx')
    data = zendao_bug_counter.get_data()
    content, project = data
    print(project)
    bug_summary = zendao_bug_counter.parser(content, project, "xxxx", start_day="2019-05-06 00:00:00", end_day="2019-05-13 00:00:00")
    print(bug_summary)

