import datetime
import time

import pymongo
import pandas as pd
from collections import Counter
import numpy as np
from elasticsearch import Elasticsearch

mappings_settings = {
            "settings": {
                "number_of_shards": 5,
                "number_of_replicas": 2
            },
            "mappings": {
                "doc": {
                    "dynamic": True,
                    "properties": {
                        "hour0": {
                            "type": "integer"
                        },
                        "hour1": {
                            "type": "integer"
                        },
                        "hour2": {
                            "type": "integer"
                        },
                        "hour3": {
                            "type": "integer"
                        },
                        "hour4": {
                            "type": "integer"
                        },
                        "hour5": {
                            "type": "integer"
                        },
                        "hour6": {
                            "type": "integer"
                        },
                        "hour7": {
                            "type": "integer"
                        },
                        "hour8": {
                            "type": "integer"
                        },
                        "hour9": {
                            "type": "integer"
                        },
                        "hour10": {
                            "type": "integer"
                        },
                        "hour11": {
                            "type": "integer"
                        },
                        "hour12": {
                            "type": "integer"
                        },
                        "hour13": {
                            "type": "integer"
                        },
                        "hour14": {
                            "type": "integer"
                        },
                        "hour15": {
                            "type": "integer"
                        },
                        "hour16": {
                            "type": "integer"
                        },
                        "hour17": {
                            "type": "integer"
                        },
                        "hour18": {
                            "type": "integer"
                        },
                        "hour19": {
                            "type": "integer"
                        },
                        "hour20": {
                            "type": "integer"
                        },
                        "hour21": {
                            "type": "integer"
                        },
                        "hour22": {
                            "type": "integer"
                        },
                        "hour23": {
                            "type": "integer"
                        },
                        "xes": {
                            "type": "integer"
                        },
                        "jzb": {
                            "type": "integer"
                        },
                        "yxx": {
                            "type": "integer"
                        },
                        "mschool": {
                            "type": "integer"
                        },
                        "total": {
                            "type": "integer"
                        },
                        "lt_115_port": {
                            "type": "integer"
                        },
                        "between_115_and_350_port": {
                            "type": "integer"
                        },
                        "gt_350_port": {
                            "type": "integer"
                        },
                        "lt_one_alg": {
                            "type": "integer"
                        },
                        "between_one_to_three_alg": {
                            "type": "integer"
                        },
                        "gt_three_alg": {
                            "type": "integer"
                        },
                        "no_title_num": {
                            "type": "integer"
                        },
                        "title_num": {
                            "type": "integer"
                        },
                        "mean_port": {
                            "type": "float"
                        },
                        "min_port": {
                            "type": "float"
                        },
                        "25%_port": {
                            "type": "float"
                        },
                        "50%_port": {
                            "type": "float"
                        },
                        "75%_port": {
                            "type": "float"
                        },
                        "90%_port": {
                            "type": "float"
                        },
                        "99%_port": {
                            "type": "float"
                        },
                        "max_port": {
                            "type": "float"
                        },
                        "mean_algorithm": {
                            "type": "float"
                        },
                        "min_algorithm": {
                            "type": "float"
                        },
                        "25%_algorithm": {
                            "type": "float"
                        },
                        "50%_algorithm": {
                            "type": "float"
                        },
                        "75%_algorithm": {
                            "type": "float"
                        },
                        "90%_algorithm": {
                            "type": "float"
                        },
                        "99%_algorithm": {
                            "type": "float"
                        },
                        "max_algorithm": {
                            "type": "float"
                        },
                        "Mon": {
                            "type": "integer"
                        },
                        "Tues": {
                            "type": "integer"
                        },
                        "Wen": {
                            "type": "integer"
                        },
                        "Thur": {
                            "type": "integer"
                        },
                        "Fri": {
                            "type": "integer"
                        },
                        "Sat": {
                            "type": "integer"
                        },
                        "Sun": {
                            "type": "integer"
                        },
                        "all_sum": {
                            "type": "integer"
                        },
                        "@timestamp": {
                            "type": "date"
                        }
                    }
                },
            }
        }
# 学而思的正则匹配
xes_regex = "xes"
# 家长帮的正则匹配
jzb_regex = "gaokaopai|aipic"
# 云学习的正则匹配
yxx_regex = 'ips'
# 魔法学校的正则匹配
mschool_regex = "tob"


# today = datetime.datetime.today()


class IkkSpider:
    def __init__(self, mappings_settings, start_date=None, end_date=None):
        self.start_date = start_date
        self.end_date = end_date
        self.mappings_settings = mappings_settings

    def create_index(self, index_name):
        self.es.indices.create(index=index_name, body=self.mappings_settings, ignore=400,timeout=100)
        # self.es.indices

    def handle(self, day, result, regex='.',  after_time=datetime.datetime(2019,1,2)):
        xes_regex_sum = 0
        jzb_regex_sum = 0
        yxx_regex_sum = 0
        mschool_regex_sum = 0
        all_sum = 0

        index_name = "ikkyyu-analysis-%s" % day.strftime("%Y.%m.%d")
        self.create_index(index_name)

        # 总的还有各业务线处理的个数
        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": xes_regex}, 'receive_time': {"$gt":day-datetime.timedelta(days=1), "$lt":day}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            xes_regex_sum = int(np.sum(list(date_counter.values())))
        except Exception as e:
            pass
        try:
            hour_count = Counter([i.hour for i in time_df.receive_time])
        except Exception as e:
            hour_count = None

        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": jzb_regex}, 'receive_time': {"$gt":day-datetime.timedelta(days=1),"$lt":day}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            jzb_regex_sum = int(np.sum(list(date_counter.values())))
        except Exception as e:
            pass

        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": yxx_regex}, 'receive_time': {"$gt":day-datetime.timedelta(days=1),"$lt":day}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            yxx_regex_sum = int(np.sum(list(date_counter.values())))
        except Exception as e:
            pass
        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": mschool_regex}, 'receive_time': {"$gt":day-datetime.timedelta(days=1),"$lt":day}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            mschool_regex_sum = int(np.sum(list(date_counter.values())))
        except Exception as e:
            pass

        # 接口的时间
        response_diff_df = pd.DataFrame(list(result.find({"source_url": {"$regex": regex},'receive_time':{"$gt":day-datetime.timedelta(days=1),"$lt":day}}, {"response_time": 1, "receive_time": 1})))

        response_diff_df['diff'] = response_diff_df.apply(
            lambda x: datetime.datetime.timestamp(x['response_time']) - datetime.datetime.timestamp(x['receive_time']),
            axis=1)
        lt_115 = len([i for i in response_diff_df['diff'] if i < 1.15])
        between_115_and_350 = len([i for i in response_diff_df['diff'] if (i < 3.5 and i > 1.15)])
        gt_350 = len([i for i in response_diff_df['diff'] if i > 3.5])

        # 算法(gpu)时间
        response_alg_df = pd.DataFrame(list(result.find({"source_url": {"$regex": regex}, 'receive_time':{"$gt":day-datetime.timedelta(days=1),"$lt":day}},
                                                        {'result.startTime': 1, 'result.endTime': 1, "_id": 0})))
        def get_diff(x):
            try:
                return x['result']['endTime'] - x['result']['startTime']
            except:
                return 0

        response_alg_df['diff'] = response_alg_df.apply(get_diff, axis=1)
        lt_one = len([i for i in response_diff_df['diff'] if i < 1])
        between_one_to_three = len([i for i in response_diff_df['diff'] if (i > 1 and i < 3)])
        gt_three = len([i for i in response_diff_df['diff'] if i > 3])

        time_df = pd.DataFrame(list(result.find({"source_url":{"$regex":regex},'receive_time':{"$gt":day-datetime.timedelta(days=1),"$lt":day}},{"receive_time":1,"_id":0})))
        date_counter = Counter([i.date() for i in time_df.receive_time])
        regex_sum = int(np.sum(list(date_counter.values())))
        weekday_count = Counter([i.weekday() for i in time_df.receive_time])

        count_no_titile = len(list(result.find(
            {"source_url": {"$regex": "."}, 'receive_time': {"$gt":day-datetime.timedelta(days=1),"$lt":day},
             "result.questionImgs": {"$size": 0}}, {})))
        count = len(list(result.find(
            {"source_url": {"$regex": "."}, 'receive_time': {"$gt":day-datetime.timedelta(days=1),"$lt":day}}, {})))
        title_num = count - count_no_titile

        # 接口的列表
        response_diff_df['diff'] = response_diff_df.apply(
            lambda x: datetime.datetime.timestamp(x['response_time']) - datetime.datetime.timestamp(x['receive_time']),
            axis=1)
        daily_port_average = np.average(response_diff_df['diff'])
        daily_port_0 = np.percentile(response_diff_df['diff'], 0)
        daily_port_25 = np.percentile(response_diff_df['diff'], 25)
        daily_port_middle = np.percentile(response_diff_df['diff'], 50)
        daily_port_75 = np.percentile(response_diff_df['diff'], 75)
        daily_port_90 = np.percentile(response_diff_df['diff'], 90)
        daily_port_99 = np.percentile(response_diff_df['diff'], 99)
        daily_port_max = np.percentile(response_diff_df['diff'], 100)

        # 算法的列表
        def get_diff(x):
            try:
                return x['result']['endTime']-x['result']['startTime']
            except:
                return 0
        response_alg_df['diff'] = response_alg_df.apply(get_diff, axis=1)
        today_algorithm_average = np.average(response_alg_df['diff'])
        today_algorithm_min = np.percentile(response_alg_df['diff'], 0)
        today_algorithm_25 = np.percentile(response_alg_df['diff'], 25)
        today_algorithm_middle = np.percentile(response_alg_df['diff'], 50)
        today_algorithm_75 = np.percentile(response_alg_df['diff'], 75)
        today_algorithm_90 = np.percentile(response_alg_df['diff'], 90)
        today_algorithm_99 = np.percentile(response_alg_df['diff'], 99)
        today_algorithm_max = np.percentile(response_alg_df['diff'], 100)
        # 总的处理个数
        time_df = pd.DataFrame(
            list(result.find({"source_url": {"$regex": regex},
                              'receive_time': {"$gt": after_time - datetime.timedelta(days=1),
                                               "$lt": day}},
                             {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            all_sum = int(np.sum(list(date_counter.values())))
            print(list(date_counter.values()))
            print(all_sum)
        except Exception as e:
            pass

        print("____________________________________")
        if hour_count:
            print("hour_count", dict(hour_count))
        else:
            hour_count = {k: 0 for k in range(0, 24)}
            print("hour_count", dict(hour_count))
        hour_count = dict(hour_count)
        for i in range(0, 24):
            dict_hour = dict()
            dt_point = day - datetime.timedelta(hours=8) + datetime.timedelta(hours=i)
            if i in hour_count:
                dict_hour[i] = hour_count[i]
                dict_hour['current'] = hour_count[i]
            else:
                dict_hour[i] = 0
                dict_hour['current'] = 0
            if i >= 10:
                dict_hour["@timestamp"] = dt_point.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            else:
                dict_hour["@timestamp"] = dt_point.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

            # print(dict_hour)
            _id = time.mktime(dt_point.timetuple()) + 60
            # print(str(_id))
            res = self.es.exists(index_name, "doc",_id)
            if not res:
                self.es.index(index=index_name, doc_type="doc", id=_id, body=dict_hour)
                print("hehe")

        dict_day = dict()
        # dict_day["@timestamp"] = day.strftime("%Y-%m-%d")

        dict_day["xes"] = xes_regex_sum
        dict_day["jzb"] = jzb_regex_sum
        dict_day["yxx"] = yxx_regex_sum
        dict_day["mschool"] = mschool_regex_sum
        dict_day["total"] = regex_sum
        dict_day["lt_115_port"] = lt_115
        dict_day["between_115_and_350_port"] = between_115_and_350
        dict_day["gt_350_port"] = gt_350
        dict_day["lt_one_alg"] = lt_one
        dict_day["between_one_to_three_alg"] = between_one_to_three
        dict_day["gt_three_alg"] = gt_three
        dict_day["no_title_num"] = count_no_titile
        dict_day["title_num"] = title_num
        dict_day["mean_port"] = daily_port_average
        dict_day["min_port"] = daily_port_0
        dict_day["25%_port"] = daily_port_25
        dict_day["50%_port"] = daily_port_middle
        dict_day["75%_port"] = daily_port_75
        dict_day["90%_port"] = daily_port_90
        dict_day["99%_port"] = daily_port_99
        dict_day["max_port"] = daily_port_max

        dict_day["mean_algorithm"] = today_algorithm_average
        dict_day["min_algorithm"] = today_algorithm_min
        dict_day["25%_algorithm"] = today_algorithm_25
        dict_day["50%_algorithm"] = today_algorithm_middle
        dict_day["75%_algorithm"] = today_algorithm_75
        dict_day["90%_algorithm"] = today_algorithm_90
        dict_day["99%_algorithm"] = today_algorithm_99
        dict_day["max_algorithm"] = today_algorithm_max
        dict_day["all_sum"] = all_sum

        for k,v in weekday_count.items():
            if k == 0:
                dict_day["Sun"] = v
            elif k == 1:
                dict_day["Mon"] = v
            elif k == 2:
                dict_day["Tues"] = v
            elif k == 3:
                dict_day["Wen"] = v
            elif k == 4:
                dict_day["Thur"] = v
            elif k == 5:
                dict_day["Fri"] = v
            elif k == 6:
                dict_day["Sat"] = v
        dt_point = day - datetime.timedelta(hours=8)
        _id = time.mktime(dt_point.timetuple())
        dict_day["@timestamp"] = dt_point.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        res = self.es.exists(index_name, "doc", _id)
        print(dict_day)
        print(dict_hour)

        if not res:
            self.es.index(index=index_name, doc_type="doc", id=_id, body=dict_day)

    def run(self):
        es = Elasticsearch([{'host': '221.122.129.39', 'port': 9200}])
        self.es = es
        now = datetime.datetime.now()
        the_begin_date = datetime.datetime(now.year, now.month, now.day) - datetime.timedelta(days=1)
        end = self.end_date if self.end_date else datetime.datetime(now.year, now.month, now.day, 0, 0, 0)
        day = the_begin_date
        delta = datetime.timedelta(days=1)
        client = pymongo.MongoClient("mongodb://root:ikkyyu_2018@dds-2zeec8ea9a65d7841295-pub.mongodb.rds.aliyuncs.com:3717")
        db = client.admin
        result = db.m_ikkyyu
        print(end)
        while day < end:
            print(day)
            day.strftime("%Y.%m.%d")
            # print(day)
            self.handle(day, result)
            day += delta


obj = IkkSpider(mappings_settings)


if __name__ == "__main__":
    obj = IkkSpider(mappings_settings)
    obj.run()
