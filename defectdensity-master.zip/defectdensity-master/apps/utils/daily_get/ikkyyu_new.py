import datetime
import time

import pymongo
import pandas as pd
from collections import Counter
import numpy as np
from elasticsearch import Elasticsearch
from elasticsearch import exceptions

MAX_ERROR_COUNT = 1

mappings_settings = {
    "settings": {
        "number_of_shards": 5,
        "number_of_replicas": 2
    },
    "mappings": {
        "doc": {
            "dynamic": True,
            "properties": {
                "hour0": {
                    "type": "integer"
                },
                "hour1": {
                    "type": "integer"
                },
                "hour2": {
                    "type": "integer"
                },
                "hour3": {
                    "type": "integer"
                },
                "hour4": {
                    "type": "integer"
                },
                "hour5": {
                    "type": "integer"
                },
                "hour6": {
                    "type": "integer"
                },
                "hour7": {
                    "type": "integer"
                },
                "hour8": {
                    "type": "integer"
                },
                "hour9": {
                    "type": "integer"
                },
                "hour10": {
                    "type": "integer"
                },
                "hour11": {
                    "type": "integer"
                },
                "hour12": {
                    "type": "integer"
                },
                "hour13": {
                    "type": "integer"
                },
                "hour14": {
                    "type": "integer"
                },
                "hour15": {
                    "type": "integer"
                },
                "hour16": {
                    "type": "integer"
                },
                "hour17": {
                    "type": "integer"
                },
                "hour18": {
                    "type": "integer"
                },
                "hour19": {
                    "type": "integer"
                },
                "hour20": {
                    "type": "integer"
                },
                "hour21": {
                    "type": "integer"
                },
                "hour22": {
                    "type": "integer"
                },
                "hour23": {
                    "type": "integer"
                },
                "xes": {
                    "type": "integer"
                },
                "jzb": {
                    "type": "integer"
                },
                "yxx": {
                    "type": "integer"
                },
                "mschool": {
                    "type": "integer"
                },
                "total": {
                    "type": "integer"
                },
                "lt_115_port": {
                    "type": "integer"
                },
                "between_115_and_350_port": {
                    "type": "integer"
                },
                "gt_350_port": {
                    "type": "integer"
                },
                "lt_one_alg": {
                    "type": "integer"
                },
                "between_one_to_three_alg": {
                    "type": "integer"
                },
                "gt_three_alg": {
                    "type": "integer"
                },
                "no_title_num": {
                    "type": "integer"
                },
                "title_num": {
                    "type": "integer"
                },
                "mean_port": {
                    "type": "float"
                },
                "min_port": {
                    "type": "float"
                },
                "25%_port": {
                    "type": "float"
                },
                "50%_port": {
                    "type": "float"
                },
                "75%_port": {
                    "type": "float"
                },
                "90%_port": {
                    "type": "float"
                },
                "99%_port": {
                    "type": "float"
                },
                "max_port": {
                    "type": "float"
                },
                "mean_algorithm": {
                    "type": "float"
                },
                "min_algorithm": {
                    "type": "float"
                },
                "25%_algorithm": {
                    "type": "float"
                },
                "50%_algorithm": {
                    "type": "float"
                },
                "75%_algorithm": {
                    "type": "float"
                },
                "90%_algorithm": {
                    "type": "float"
                },
                "99%_algorithm": {
                    "type": "float"
                },
                "max_algorithm": {
                    "type": "float"
                },
                "Mon": {
                    "type": "integer"
                },
                "Tues": {
                    "type": "integer"
                },
                "Wen": {
                    "type": "integer"
                },
                "Thur": {
                    "type": "integer"
                },
                "Fri": {
                    "type": "integer"
                },
                "Sat": {
                    "type": "integer"
                },
                "Sun": {
                    "type": "integer"
                },
                "all_sum": {
                    "type": "integer"
                },
                "@timestamp": {
                    "type": "date"
                }
            }
        },
    }
}
# 学而思的正则匹配
xes_regex = "xes"
# 家长帮的正则匹配
jzb_regex = "gaokaopai|aipic"
# 云学习的正则匹配
yxx_regex = 'ips'
# 魔法学校的正则匹配
mschool_regex = "tob"


def get_logger():
    import logging

    logger = logging.getLogger("ikkyyu")
    logger.setLevel(logging.DEBUG)

    # 建立一个filehandler来把日志记录在文件里，级别为debug以上
    fh = logging.FileHandler("ikkyyu.log")
    fh.setLevel(logging.DEBUG)

    # 建立一个streamhandler来把日志打在CMD窗口上，级别为error以上
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    # 设置日志格式
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch.setFormatter(formatter)
    fh.setFormatter(formatter)

    # 将相应的handler添加在logger对象中
    logger.addHandler(ch)
    logger.addHandler(fh)

    return logger


class IkkSpider:
    def __init__(self, mappings_settings, start_date=None, end_date=None):
        self.start_date = start_date
        self.end_date = end_date
        self.mappings_settings = mappings_settings
        self.logger = get_logger()
        self.es = self.connect_es()

    # def create_index(self, index_name):
    #
    #     retry_count = 0
    #     try:
    #         self.es.indices.get(index_name)
    #     except exceptions.NotFoundError:
    #         while True:
    #             try:
    #                 self.es.indices.create(index=index_name, body=self.mappings_settings, ignore=400, timeout=60)
    #                 self.logger.info("创建索引成功")
    #                 time.sleep(35)   # 解决mapping不能频繁创建问题
    #                 return True
    #             except Exception as e:
    #                 self.logger.error(str(e))
    #                 self.logger.warning("第%s次重试创建索引中", str(retry_count))
    #                 retry_count += 1
    #                 if retry_count >= 3:
    #                     self.logger.warning("重试3次失败")
    #                     return False
    #                 continue

    def connect_es(self):
        es = Elasticsearch([{'host': '221.122.129.39', 'port': 9200}])
        return es

    def get_diff(self, x):
        try:
            return x['result']['endTime'] - x['result']['startTime']
        except Exception as e:
            self.logger.info(str(e))
            return 0

    def census_data_day(self, day, result, pre_index_name, regex='.'):
        xes_regex_sum = 0
        jzb_regex_sum = 0
        yxx_regex_sum = 0
        mschool_regex_sum = 0
        all_sum = 0

        # 总的还有各业务线处理的个数
        self.logger.info("开始统计各业务线调用量")

        self.logger.info("开始统计学而思调用量")
        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": xes_regex},
                                                 'receive_time': {"$gt": day,
                                                                  "$lt": day + datetime.timedelta(days=1)}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            xes_regex_sum = int(np.sum(list(date_counter.values())))
            flag = True
        except Exception as e:
            self.logger.error("统计学而思调用量失败")
            self.logger.error(str(e))
            flag = False
        if flag:
            self.logger.info("统计学而思调用量成功")
        else:
            self.logger.error("统计学而思调用量失败")

        self.logger.info("开始统计家长帮调用量")
        time_df = pd.DataFrame(list(result.find(
            {"source_url": {"$regex": jzb_regex},
             'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
            {"receive_time": 1, "_id": 0})
        )
        )
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            jzb_regex_sum = int(np.sum(list(date_counter.values())))
            flag = True
        except Exception as e:
            self.logger.error(str(e))
            flag = False
        if flag:
            self.logger.info("统计家长帮调用量成功")
        else:
            self.logger.error("统计家长帮调用量失败")
        self.logger.info("开始统计云学习调用量")
        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": yxx_regex},
                                                 'receive_time': {"$gt": day,
                                                                  "$lt": day + datetime.timedelta(days=1)}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            yxx_regex_sum = int(np.sum(list(date_counter.values())))
            flag = True
        except Exception as e:
            self.logger.error(str(e))
            flag = False
        if flag:
            self.logger.info("统计云学习调用量成功")
        else:
            self.logger.error("统计云学习调用量失败")

        self.logger.info("开始统计魔法校调用量")
        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": mschool_regex},
                                                 'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
                                                {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            mschool_regex_sum = int(np.sum(list(date_counter.values())))
            flag = True
        except Exception as e:
            self.logger.error(str(e))
            flag = False
        if flag:
            self.logger.info("统计魔法校调用量成功")
        else:
            self.logger.error("统计魔法校调用量失败")

        # 接口的时间
        self.logger.info("开始统计接口调用时间")
        response_diff_df = pd.DataFrame(list(result.find(
            {"source_url": {"$regex": regex},
             'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
            {"response_time": 1, "receive_time": 1})))

        response_diff_df['diff'] = response_diff_df.apply(
            lambda x: datetime.datetime.timestamp(x['response_time']) - datetime.datetime.timestamp(
                x['receive_time']),
            axis=1)
        lt_115 = len([i for i in response_diff_df['diff'] if i < 1.15])
        between_115_and_350 = len([i for i in response_diff_df['diff'] if (i < 3.5 and i > 1.15)])
        gt_350 = len([i for i in response_diff_df['diff'] if i > 3.5])
        self.logger.info("统计接口调用时间成功")

        # 算法(gpu)时间
        self.logger.info("开始统计算法调用时间")
        response_alg_df = pd.DataFrame(list(result.find(
            {"source_url": {"$regex": regex},
             'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
            {'result.startTime': 1, 'result.endTime': 1, "_id": 0})))

        response_alg_df['diff'] = response_alg_df.apply(self.get_diff, axis=1)
        lt_one = len([i for i in response_diff_df['diff'] if i < 1])
        between_one_to_three = len([i for i in response_diff_df['diff'] if (i > 1 and i < 3)])
        gt_three = len([i for i in response_diff_df['diff'] if i > 3])

        time_df = pd.DataFrame(list(result.find(
            {"source_url": {"$regex": regex},
             'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
            {"receive_time": 1, "_id": 0})))
        date_counter = Counter([i.date() for i in time_df.receive_time])
        regex_sum = int(np.sum(list(date_counter.values())))
        weekday_count = Counter([i.weekday() for i in time_df.receive_time])

        count_no_titile = len(list(result.find(
            {"source_url": {"$regex": regex}, 'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)},
             "result.questionImgs": {"$size": 0}}, {})))
        count = len(list(result.find(
            {"source_url": {"$regex": regex}, 'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
            {})))
        title_num = count - count_no_titile
        self.logger.info("统计算法调用时间成功")
        # 接口的列表
        response_diff_df['diff'] = response_diff_df.apply(
            lambda x: datetime.datetime.timestamp(x['response_time']) - datetime.datetime.timestamp(
                x['receive_time']),
            axis=1)
        daily_port_average = np.average(response_diff_df['diff'])
        daily_port_0 = np.percentile(response_diff_df['diff'], 0)
        daily_port_25 = np.percentile(response_diff_df['diff'], 25)
        daily_port_middle = np.percentile(response_diff_df['diff'], 50)
        daily_port_75 = np.percentile(response_diff_df['diff'], 75)
        daily_port_90 = np.percentile(response_diff_df['diff'], 90)
        daily_port_99 = np.percentile(response_diff_df['diff'], 99)
        daily_port_max = np.percentile(response_diff_df['diff'], 100)

        # 算法的列表
        response_alg_df['diff'] = response_alg_df.apply(self.get_diff, axis=1)
        today_algorithm_average = np.average(response_alg_df['diff'])
        today_algorithm_min = np.percentile(response_alg_df['diff'], 0)
        today_algorithm_25 = np.percentile(response_alg_df['diff'], 25)
        today_algorithm_middle = np.percentile(response_alg_df['diff'], 50)
        today_algorithm_75 = np.percentile(response_alg_df['diff'], 75)
        today_algorithm_90 = np.percentile(response_alg_df['diff'], 90)
        today_algorithm_99 = np.percentile(response_alg_df['diff'], 99)
        today_algorithm_max = np.percentile(response_alg_df['diff'], 100)
        # 总的处理个数
        # 获取前一天之前的总处理量
        dt_point = day - datetime.timedelta(hours=8) - datetime.timedelta(days=1)
        _id = time.mktime(dt_point.timetuple())
        try:
            res = self.es.get(pre_index_name, "doc", _id)
            prev_all_sum = res["_source"]["all_sum"]
            self.logger.info(res)
            self.logger.info("获取前一天的总调用量成功")
        except exceptions.NotFoundError:
            global MAX_ERROR_COUNT
            if MAX_ERROR_COUNT > 0:
                prev_all_sum = 0
                self.logger.info("获取前一天的总调用量失败")
            else:
                self.logger.info("获取前一天的总调用量失败")
                raise ValueError

        # 获取当天的总处理量
        time_df = pd.DataFrame(
            list(result.find({"source_url": {"$regex": regex},
                              'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
                             {"receive_time": 1, "_id": 0})))
        try:
            date_counter = Counter([i.date() for i in time_df.receive_time])
            all_sum = int(np.sum(list(date_counter.values()))) + prev_all_sum
        except Exception as e:
            self.logger.error(str(e))

        dict_day = dict()
        # dict_day["@timestamp"] = day.strftime("%Y-%m-%d")
        dict_day["xes"] = xes_regex_sum
        dict_day["jzb"] = jzb_regex_sum
        dict_day["yxx"] = yxx_regex_sum
        dict_day["mschool"] = mschool_regex_sum
        dict_day["total"] = regex_sum
        dict_day["lt_115_port"] = lt_115
        dict_day["between_115_and_350_port"] = between_115_and_350
        dict_day["gt_350_port"] = gt_350
        dict_day["lt_one_alg"] = lt_one
        dict_day["between_one_to_three_alg"] = between_one_to_three
        dict_day["gt_three_alg"] = gt_three
        dict_day["no_title_num"] = count_no_titile
        dict_day["title_num"] = title_num
        dict_day["mean_port"] = daily_port_average
        dict_day["min_port"] = daily_port_0
        dict_day["25%_port"] = daily_port_25
        dict_day["50%_port"] = daily_port_middle
        dict_day["75%_port"] = daily_port_75
        dict_day["90%_port"] = daily_port_90
        dict_day["99%_port"] = daily_port_99
        dict_day["max_port"] = daily_port_max

        dict_day["mean_algorithm"] = today_algorithm_average
        dict_day["min_algorithm"] = today_algorithm_min
        dict_day["25%_algorithm"] = today_algorithm_25
        dict_day["50%_algorithm"] = today_algorithm_middle
        dict_day["75%_algorithm"] = today_algorithm_75
        dict_day["90%_algorithm"] = today_algorithm_90
        dict_day["99%_algorithm"] = today_algorithm_99
        dict_day["max_algorithm"] = today_algorithm_max
        dict_day["all_sum"] = all_sum

        weekday_mapping ={
            0: "Mon",
            1: "Tues",
            2: "Wen",
            3: "Thur",
            4: "Fri",
            5: "Sat",
            6: "Sun",
        }
        for k, v in weekday_count.items():
            dict_day[weekday_mapping[k]] = v
        dt_point = day - datetime.timedelta(hours=8)
        dict_day["@timestamp"] = dt_point.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        return dict_day

    def census_data_hour(self, day, result):
        # 统计每小时调用量
        time_df = pd.DataFrame(list(result.find({"source_url": {"$regex": "."},
                                                 'receive_time': {"$gt": day, "$lt": day + datetime.timedelta(days=1)}},
                                                {"receive_time": 1, "_id": 0})))
        hour_count = None
        try:
            hour_count = Counter([i.hour for i in time_df.receive_time])
            flag = True
        except Exception as e:
            self.logger.error(str(e))
            flag = False
        if flag:
            self.logger.info("统计%s 每小时的处理量成功" % day.strftime("%Y-%m-%d"))
        else:
            self.logger.error("统计%s 每小时的处理量失败" % day.strftime("%Y-%m-%d"))

        if not flag:
            hour_count = {k: 0 for k in range(0, 24)}

        hour_count = dict(hour_count)
        return hour_count

    def write_es(self, day, result):
        # 创建索引
        index_name = "ikkyyu-data-%s" % day.strftime("%Y.%m.%d")
        # self.create_index(index_name)

        # 插入小时数据
        flag = True  # 判断是否已经获取过小时数据
        hour_count = None
        self.logger.info("开始统计所有业务线每小时的处理量")
        for hour in range(0, 24):
            dt_point = day - datetime.timedelta(hours=8) + datetime.timedelta(hours=hour)
            _id = time.mktime(dt_point.timetuple()) + 60
            res = self.es.exists(index_name, "doc", _id)
            if not res:
                # if hour == 0:
                #     time.sleep(35)  # 解决mapping不能频繁创建问题
                if flag:
                    hour_count = self.census_data_hour(day, result)

                flag = False
                dt_point = day - datetime.timedelta(hours=8) + datetime.timedelta(hours=hour)
                dict_hour = dict()
                if hour in hour_count:
                    dict_hour[hour] = hour_count[hour]
                    dict_hour['current'] = hour_count[hour]
                else:
                    dict_hour[hour] = 0
                    dict_hour['current'] = 0
                if hour >= 10:
                    dict_hour["@timestamp"] = dt_point.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
                else:
                    dict_hour["@timestamp"] = dt_point.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
                try:
                    self.es.index(index=index_name, doc_type="doc", id=_id, body=dict_hour)
                except exceptions.ConnectionTimeout:
                    self.logger.error("exceptions.ConnectionTimeout")
                self.logger.info("%s %s时的数据插入成功" % (day.strftime("%Y-%m-%d"), str(hour)))
            else:
                self.logger.warning("%s %s时的数据已存在，插入失败" % (day.strftime("%Y-%m-%d"), str(hour)))
        # 插入天数据
        dt_point = day - datetime.timedelta(hours=8)
        _id = time.mktime(dt_point.timetuple())
        res = self.es.exists(index_name, "doc", _id)
        if not res:
            prev_index_name = "ikkyyu-data-%s" % (day - datetime.timedelta(days=1)).strftime("%Y.%m.%d")
            dict_day = self.census_data_day(day, result, prev_index_name)
            self.es.index(index=index_name, doc_type="doc", id=_id, body=dict_day)
            self.logger.info("%s 的数据插入成功" % day.strftime("%Y-%m-%d"))
        else:
            self.logger.warning("%s 的数据已存在，插入失败" % day.strftime("%Y-%m-%d"))

    def run(self):
        now = datetime.datetime.now()
        the_begin_date = datetime.datetime(now.year, now.month, now.day) - datetime.timedelta(days=7)
        # the_begin_date = datetime.datetime(2019, 1, 2)
        end = self.end_date if self.end_date else datetime.datetime(now.year, now.month, now.day, 0, 0, 0)
        day = the_begin_date
        delta = datetime.timedelta(days=1)
        client = pymongo.MongoClient(
            "mongodb://root:ikkyyu_2018@dds-2zeec8ea9a65d7841295-pub.mongodb.rds.aliyuncs.com:3717")
        db = client.admin
        result = db.m_ikkyyu
        self.logger.info("----------------------------------------")
        while day < end:
            self.logger.info("开始处理 %s 的数据" % day.strftime("%Y.%m.%d"))
            self.write_es(day, result)
            self.logger.info("处理 %s 的数据成功" % day.strftime("%Y.%m.%d"))
            self.logger.info("----------------------------------------")
            day += delta

obj = IkkSpider(mappings_settings)
# if __name__ == "__main__":
#     obj = IkkSpider(mappings_settings)
#     obj.run()
