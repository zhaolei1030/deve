import requests
from elasticsearch import Elasticsearch

import datetime
import time
import pymysql


# 获取一个数据库连接，注意如果是UTF-8类型的，需要制定数据库


class DingTalk:
    def __init__(self, url):
        """

        :param content: str
        :param url: str
        :param at_mobiles: list
        :param msg_type: str
        :param at_all: bool
        """
        self.url = url

    def send_msg(self, content, at_mobiles, msg_type='text', at_all=False, title=''):
        if msg_type == 'text':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'text': {'content': content}
            }
            return requests.post(self.url, json=data)
        if msg_type == 'markdown':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'markdown': {'title': title, 'text': content}
            }
            print(title, content)
            return requests.post(self.url, json=data)


def send_daily_report():
    """
    Tips:如果日报发送失败是因为sql语句执行失败的话，则可能是因为研发那边数据库数据没有更新，可以@昭淳 处理一下
    :return:
    """
    today = datetime.date.today()
    today_timestamp = time.mktime(today.timetuple())
    yesterday = (today - datetime.timedelta(days=1))
    yesterday_timestamp = time.mktime(yesterday.timetuple())
    print(today_timestamp, yesterday_timestamp)
    try:
        conn = pymysql.connect(host='39.105.66.41', user='dashboard', passwd='vguilzd8320c', db='hive_koushuti',
                               port=3306, charset='utf8')
        cur = conn.cursor()  # 获取一个游标
        cur.execute("""SELECT
          date_add(date, interval -8 hour) AS "time",
           sum(auto_correct) AS "所有年级"
        FROM tb_dashboard
        WHERE
          date BETWEEN FROM_UNIXTIME(%s) AND FROM_UNIXTIME(%s) 
        group by date
        ORDER BY date""", (yesterday_timestamp, today_timestamp))
        data = cur.fetchall()
        auxiliary_count_corrections = 0
        for d in data:
            auxiliary_count_corrections += list(d)[1]
        cur.execute("""SELECT
          date_add(date, interval -8 hour) AS "time",
          sum(all_aceept)/sum(auto_correct) AS "总接受率"
        FROM tb_dashboard
        WHERE
          date BETWEEN FROM_UNIXTIME(%s) AND FROM_UNIXTIME(%s)
        group by date
        ORDER BY date""", (yesterday_timestamp, today_timestamp))
        data = cur.fetchall()
        for i in data:
            all_accept_percent = list(i)[1]
            print(all_accept_percent)
        sql = """SELECT
          date_add(date, interval -8 hour) AS "time",
          sum(star_aceept)/sum(auto_correct) AS "星级接受率"
        FROM tb_dashboard
        WHERE
          date BETWEEN FROM_UNIXTIME({yesterday_timestamp}) AND FROM_UNIXTIME({today_timestamp})
        group by date
        ORDER BY date""".format(yesterday_timestamp=yesterday_timestamp, today_timestamp=today_timestamp)
        print(sql)
        cur.execute("""SELECT
          date_add(date, interval -8 hour) AS "time",
          sum(star_aceept)/sum(auto_correct) AS "星级接受率"
        FROM tb_dashboard
        WHERE
          date BETWEEN FROM_UNIXTIME(%s) AND FROM_UNIXTIME(%s)
        group by date
        ORDER BY date""", (yesterday_timestamp, today_timestamp))
        data = cur.fetchall()
        for i in data:
            star_accept_percent = list(i)[1]
            print(star_accept_percent)
        cur.close()  # 关闭游标
        conn.close()  # 释放数据库资源
    except  Exception:
        print("查询失败")

    today = datetime.date.today()
    today_timestamp = time.mktime(today.timetuple())
    # today_timestamp = today.strftime("%s")
    yesterday = (today - datetime.timedelta(days=1))
    yesterday_timestamp = time.mktime(yesterday.timetuple())
    # yesterday_timestamp = yesterday.strftime("%s")
    project_name = "口述题"
    index_name = "koushuti-server-*"
    # template = """#### {date} 运营分析日报
    # 项目：{project_name}
    # 处理完成数：{process_total}
    # 最大队列长度：{max_queue_len}
    # 最大处理时长：{max_process_time}
    # 异常返回码总数：{wrong_code_total}
    # 异常返回码占比：{wrong_code_percent}
    # """
    es = Elasticsearch([{'host': '221.122.129.39', 'port': 9200}])
    _query_name_contains = {
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:1001",
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                            }
                        }
                    }
                ]
            }
        }
    }
    process_total = es.count(index=index_name, body=_query_name_contains)['count']

    _query_name_contains = {
        "aggs": {
            "1": {
                "max": {
                    "field": "queue_len"
                }
            }
        },
        "size": 0,
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "query_string": {
                            "query": "code:1002",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                            }
                        }
                    }
                ],

            }
        }
    }
    max_queue_len = es.search(index=index_name, body=_query_name_contains)['aggregations']['1']['value']

    _query_name_contains = {
        "aggs": {
            "1": {
                "max": {
                    "field": "spend_time"
                }
            }
        },
        "size": 0,
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "query_string": {
                            "query": "code:1001",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                            }
                        }
                    }
                ],

            }
        }
    }

    max_process_time = es.search(index=index_name, body=_query_name_contains)['aggregations']['1']['value']

    _query_name_contains = {
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:[100 TO 199]",
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                            }
                        }
                    }
                ]
            }
        }
    }
    wrong_code_total = es.count(index=index_name, body=_query_name_contains)['count']
    _query_name_contains = {
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:[0 TO 199]",
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                            }
                        }
                    }
                ]
            }
        }
    }
    code_total = es.count(index=index_name, body=_query_name_contains)['count']
    if code_total:
        wrong_code_percent = wrong_code_total / code_total
    else:
        wrong_code_percent = 0

    _query_name_contains = {
        "aggs": {
            "2": {
                "filters": {
                    "filters": {
                        "北京": {
                            "query_string": {
                                "query": "city_code:010",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "上海": {
                            "query_string": {
                                "query": "city_code:021",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "深圳": {
                            "query_string": {
                                "query": "city_code:0755",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "重庆": {
                            "query_string": {
                                "query": "city_code:023",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "天津": {
                            "query_string": {
                                "query": "city_code:022",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "广州": {
                            "query_string": {
                                "query": "city_code:020",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "杭州": {
                            "query_string": {
                                "query": "city_code:0571",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "成都": {
                            "query_string": {
                                "query": "city_code:028",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "南京": {
                            "query_string": {
                                "query": "city_code:025",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "郑州": {
                            "query_string": {
                                "query": "city_code:0371",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "武汉": {
                            "query_string": {
                                "query": "city_code:027",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "苏州": {
                            "query_string": {
                                "query": "city_code:0512",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "西安": {
                            "query_string": {
                                "query": "city_code:029",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        }

                    }
                }
            }
        },
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "query_string": {
                            "query": "code:1001",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ]
            }
        }
    }
    city_info = es.search(index=index_name, body=_query_name_contains)['aggregations']['2']['buckets']
    city_dist = ""
    T1 = city_info["北京"]["doc_count"] + city_info["上海"]["doc_count"] + city_info["广州"]["doc_count"] + city_info["深圳"][
        "doc_count"] + \
         city_info["南京"]["doc_count"] + city_info["杭州"]["doc_count"]
    T2 = city_info["郑州"]["doc_count"] + city_info["西安"]["doc_count"] + city_info["武汉"]["doc_count"] + city_info["天津"][
        "doc_count"] + \
         city_info["苏州"]["doc_count"] + city_info["成都"]["doc_count"]
    T3 = city_info["重庆"]["doc_count"]
    print(T1, T2, T3)
    for city in city_info:
        if not city_dist:
            city_dist += "- {city}：{count}".format(city=city, count=city_info[city]['doc_count'])
        else:
            city_dist += "\n- {city}：{count}".format(city=city, count=city_info[city]['doc_count'])

    _query_name_contains = {
        "aggs": {
            "2": {
                "filters": {
                    "filters": {
                        "0 - 5 分钟": {
                            "query_string": {
                                "query": "spend_time: [0 TO 300000]",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "5 - 10 分钟": {
                            "query_string": {
                                "query": "spend_time: [300001 TO 600000]",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },
                        "10分钟以上": {
                            "query_string": {
                                "query": "spend_time: [600001 TO *]",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        },

                        "30分钟以上": {
                            "query_string": {
                                "query": "spend_time: [1800001 TO *]",
                                "analyze_wildcard": True,
                                "default_field": "*"
                            }
                        }
                    }
                }
            }
        },
        "size": 0,
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "query_string": {
                            "query": "code:1001",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ]
            }
        }
    }
    process_time_info = es.search(index=index_name, body=_query_name_contains)['aggregations']['2']['buckets']
    print(process_time_info)
    process_time_dist = ""
    manage_gt_30 = process_time_info['30分钟以上']['doc_count']
    print(process_time_info)
    # process_time_info['10分钟以上']['doc_count']
    for process_time in process_time_info:
        if not process_time_dist:
            process_time_dist += "- {process_time}：{count}".format(process_time=process_time,
                                                                   count=process_time_info[process_time]['doc_count'])
        else:
            process_time_dist += "\n- {process_time}：{count}".format(process_time=process_time,
                                                                     count=process_time_info[process_time]['doc_count'])
    print(process_time_dist)
    template = """#### {date} 运营分析日报
**项目**：{project_name}  
**处理完成数**：{process_total}  
**最大队列长度**：{max_queue_len}  
**最大处理时长**：{max_process_time}min  
**处理时间超过30分钟**: {manage_gt_30}  
**异常码返回**：{wrong_code_total}/{wrong_code_percent}%  
**请求处理分布**:  
- T1(北上广深南杭): {T1}  
- T2(郑西武天苏成): {T2}  
- T3-T5: {T3}   

**辅助批改量**: {auxiliary_count_corrections}  
**总接收率**: {all_accept_percent}%  
**星级接受率**: {star_accept_percent}%  

"""
    content = template.format(
        date=yesterday.strftime("%Y-%m-%d"),
        project_name=project_name,
        process_total=process_total,
        max_queue_len=int(max_queue_len) if max_queue_len else 0,
        max_process_time=round((max_process_time / 60000), 1),
        wrong_code_total=wrong_code_total,
        wrong_code_percent=round(wrong_code_percent * 100, 4),
        city_dist=city_dist,
        process_time_dist=process_time_dist,
        manage_gt_30=manage_gt_30,
        all_accept_percent=round((all_accept_percent * 100), 2),
        star_accept_percent=round((star_accept_percent * 100), 2),
        auxiliary_count_corrections=auxiliary_count_corrections,
        T1=T1,
        T2=T2,
        T3=process_total - T1 - T2,
    )
    print(content)

    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=05b3691fe01d5c581a17d90f4d87e16ffbdda64008b4efbf791f9130443517f6')
    # obj = DingTalk('https://oapi.dingtalk.com/robot/send?access_token=d357da381ca3c64629f17f2490777b454b211cf0ecf167ad4691179930e9de47')  #gehang
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))
    #
    # 发送到总群
    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=c988c827d87c7742f945ad0417f6f77110863420bd445e45a5b0825f9a2b0729')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))


if __name__ == "__main__":
    send_daily_report()
