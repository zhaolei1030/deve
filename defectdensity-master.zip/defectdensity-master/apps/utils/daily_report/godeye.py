import datetime
import time
import requests
import math
import numpy as np
from elasticsearch import Elasticsearch
# import es_client
from elasticsearch import helpers


class DingTalk:
    def __init__(self, url):
        """
        :param content: str
        :param url: str
        :param at_mobiles: list
        :param msg_type: str
        :param at_all: bool
        """
        self.url = url

    def send_msg(self, content, at_mobiles, msg_type='text', at_all=False, title=''):
        if msg_type == 'text':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'text': {'content': content}
            }
            return requests.post(self.url, json=data)
        if msg_type == 'markdown':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'markdown': {'title': title, 'text': content}
            }
            print(title, content)
            return requests.post(self.url, json=data)

def get_course_list_by_code(code,start_time_stamp,end_time_stamp,es):
    index_name = "godeye-server-*"
    _query_name_contains = {
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code: " + str(code),
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(start_time_stamp) * 1000,
                                "lte": int(end_time_stamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_course_list = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_course_list.append(course_id)

    return set(final_course_list)
def send_daily_report():
    inceptiondate = int(1555297856) # 起始时间 2019.04.15 11:10
    today = datetime.date.today()  # 获取当前日期
    today_timestamp = int(time.mktime(today.timetuple())) + 28800
    yesterday = (today - datetime.timedelta(days=1))
    yesterday_timestamp = int(time.mktime(yesterday.timetuple())) + 28800
    #inceptiondate = int(1555905600)
    #today_timestamp = 1555040524
    #yesterday_timestamp = 1555039486

    # inceptiondate = int(1557906018)
    # today_timestamp = 1558149720
    # yesterday_timestamp = 1557906018
    project_name = "Godeye"
    index_name = "godeye-server-*"
    # 线上
    es = Elasticsearch([{'host': '221.122.129.39', 'port': 9200}])
    # 测试
    #es = Elasticsearch([{'host': '221.122.129.43', 'port': 9200}])


    _query_name_contains = {
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:0",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }


    processtotal_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')

    final_processtotalresult = []
    for item in processtotal_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_processtotalresult.append(course_id)
    intnoprocetotal = len(final_processtotalresult)
    daily_process_total = set(final_processtotalresult)
    process_total = len(daily_process_total)




    _query_name_contains = {
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:0",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(inceptiondate) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }
    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m',raise_on_error=False, index=index_name, timeout='1m')

    final_result = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_result.append(course_id)
    daily_removeduplicate_totalcourse = set(final_result)
    daily_removeduplicate_totalcoursesize = len(daily_removeduplicate_totalcourse)

    _query_name_contains = {
        "aggs": {
            "2": {
                "filters": {
                    "filters": {
                        "Godeye服务端": {
                            "query_string": {
                                "query": "code:[104 TO 199]",
                                "analyze_wildcard": 'true',
                                "default_field": "*"
                            }
                        }
                    }
                }
            }
        },
        "size": 0,
        "_source": {
            "excludes": []
        },
        "stored_fields": [
            "*"
        ],
        "script_fields": {},
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "match_all": {}
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }
    wrong_code_total = \
        es.search(index=index_name, body=_query_name_contains)['aggregations']["2"]["buckets"]["Godeye服务端"][
            'doc_count']

    #
    _query_name_contains = {
        "aggs": {
            "2": {
                "terms": {
                    "field": "code",
                    "size": 20,
                    "order": {
                        "_count": "desc"
                    }
                }
            }
        },
        "size": 0,
        "_source": {
            "excludes": []
        },
        "stored_fields": [
            "*"
        ],
        "script_fields": {},
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "match_all": {}
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }

    code_list = es.search(index=index_name, body=_query_name_contains)['aggregations']["2"]["buckets"]
    print(code_list)
    audio_fail_total = 0
    video_fail_total = 0
    download_fail_total = 0
    # socket_link_fail_total = 0
    abnormal_class_total = 0

    for code in code_list:
        if str(code["key"]) == "109":
            audio_fail_total = code["doc_count"]
        elif str(code["key"]) == "108":
            video_fail_total = code["doc_count"]
        elif str(code["key"]) == "110":
            download_fail_total = code["doc_count"]
        # elif str(code["key"]) == "111" or str(code["key"]) == "112":
        #     socket_link_fail_total += code["doc_count"]
        elif str(code["key"]) == "114":
            abnormal_class_total = code["doc_count"]
    if process_total:
        class_analyze_failure_rate = abnormal_class_total / process_total
    else:
        class_analyze_failure_rate = 0
    code_info = ""
    code_dict = {"104": "104 打分模型", "105": "105 退费模型", "106": "106 人脸框模型", "107": "107 表情模型", "108": "108 视频分析",
                 "109": "109 音频分析", "110": "110 下载"}
    for code in code_list:
        if str(code["key"]) in list(code_dict.keys()):
            if not code_info:
                code_info += "- {code}：{count}".format(code=code_dict[str(code["key"])], count=code["doc_count"])
            else:
                code_info += "\n- {code}：{count}".format(code=code_dict[str(code["key"])], count=code["doc_count"])
    _query_name_contains = {
        "aggs": {
            "2": {
                "filters": {
                    "filters": {
                        "正常返回码": {
                            "query_string": {
                                "query": "code:[0 TO 99]",
                                "analyze_wildcard": 'true',
                                "default_field": "*"
                            }
                        },
                        "错误返回码": {
                            "query_string": {
                                "query": "code:[100 TO 199]",
                                "analyze_wildcard": 'true',
                                "default_field": "*"
                            }
                        }
                    }
                }
            }
        },
        "size": 0,
        "_source": {
            "excludes": []
        },
        "stored_fields": [
            "*"
        ],
        "script_fields": {},
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "match_all": {}
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }
    code_analysis = es.search(index=index_name, body=_query_name_contains)['aggregations']["2"]["buckets"]
    Normal_code = code_analysis['正常返回码']['doc_count']
    Error_code = code_analysis['错误返回码']['doc_count']

    _query_name_contains = {
        "aggs": {
            "1": {
                "avg": {
                    "field": "cost_time"
                }
            }
        },
        "size": 0,
        "_source": {
            "excludes": []
        },
        "stored_fields": [
            "*"
        ],
        "script_fields": {},
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:1002",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }

    video_avgcosttime = es.search(index=index_name, body=_query_name_contains)['aggregations']['1']['value']
    if video_avgcosttime is None:
        video_avgcosttime = video_avgcosttime
    if not video_avgcosttime is None:
        video_avgcosttime = video_avgcosttime / 60000
    video_cost_time_info = ""
    video_total = 0
    _query_name_contains = {
        "aggs": {
            "1": {
                "avg": {
                    "field": "cost_time"
                }
            }
        },
        "size": 0,
        "_source": {
            "excludes": []
        },
        "stored_fields": [
            "*"
        ],
        "script_fields": {},
        "docvalue_fields": [
            {
                "field": "@timestamp",
                "format": "date_time"
            }
        ],
        "query": {
            "bool": {
                "must": [
                    {
                        "query_string": {
                            "query": "code:1003",
                            "analyze_wildcard": True,
                            "default_field": "*"
                        }
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ],
                "filter": [],
                "should": [],
                "must_not": []
            }
        }
    }

    audio_avgcosttime = es.search(index=index_name, body=_query_name_contains)['aggregations']["1"]["value"]
    if audio_avgcosttime is None:
        audio_avgcosttime = audio_avgcosttime
    if not audio_avgcosttime is None:
        audio_avgcosttime = audio_avgcosttime / 60000

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1003"
                    }
                }]
            }
        }
    }
    #当日返回课堂　－－－－－－－－－获取当日推送课堂ＩＤ和当日返回课堂ＩＤ

    #audio_total_value = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    audio_total_value_totalcounts = helpers.scan(client=es, query=_query_name_contains, scroll='5m',raise_on_error=False, index=index_name, timeout='1m')

    final_audio_total_value_totalcounts = []
    for item in audio_total_value_totalcounts:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_audio_total_value_totalcounts.append(course_id)
    daily_audio_total_value = set(final_audio_total_value_totalcounts)
    listdaily_audio_total_value = list(daily_audio_total_value)
    listdaily_process_total = list(daily_process_total)
    currentdaylist=[]
    yesterdaylist=[]
    # 从返回的数据里区分　当日返回的，历史返回的结果
    for x in listdaily_audio_total_value:
        if(x in listdaily_process_total):
            currentdaylist.append(x)
        elif(x not  in listdaily_process_total):
            yesterdaylist.append(x)


    audio_total_value = len(currentdaylist)
    yesterdayret = len(yesterdaylist)

    #昨日返回课堂



    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1002"
                    }
                }]
            }
        }
    }

    video_total_value = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    # _query_name_contains = {
    #     "size": 0,
    #     "query": {
    #         "bool": {
    #             "filter": [{
    #                 "range": {
    #                     "@timestamp": {
    #                         "gte": int(yesterday_timestamp) * 1000,
    #                         "lte": int(today_timestamp) * 1000,
    #                         "format": "epoch_millis"
    #                     }
    #                 }
    #             }, {
    #                 "query_string": {
    #                     "analyze_wildcard": True,
    #                     "query": "code:1004"
    #                 }
    #             }]
    #         }
    #     },
    #     "aggs": {
    #         "4": {
    #             "date_histogram": {
    #                 "interval": "30m",
    #                 "field": "@timestamp",
    #                 "min_doc_count": 0,
    #                 "extended_bounds": {
    #                     "min": "1548172800000",
    #                     "max": "1548259199999"
    #                 },
    #                 "format": "epoch_millis"
    #             },
    #             "aggs": {}
    #         }
    #     }
    # }

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1004"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }


    #audio_drop_value = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    audio_drop_value = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                                                 raise_on_error=False,
                                                 index=index_name,
                                                 timeout='1m')

    final_audio_drop_value = []
    for item in audio_drop_value:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_audio_drop_value.append(course_id)
    daily_final_audio_drop_value = set(final_audio_drop_value)
    audio_drop_value = len(daily_final_audio_drop_value)


    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1005"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }

    #asr_convert_fail = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    asr_convert_fail = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                                                 raise_on_error=False,
                                                 index=index_name,
                                                 timeout='1m')

    final_asr_convert_fail = []
    for item in asr_convert_fail:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_asr_convert_fail.append(course_id)
    daily_final_asr_convert_fail = set(final_asr_convert_fail)
    asr_convert_fail = len(daily_final_asr_convert_fail)



    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1006"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #no_teacher_video = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    no_teacher_video = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                                    raise_on_error=False,
                                    index=index_name,
                                    timeout='1m')

    final_no_teacher_video = []
    for item in no_teacher_video:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_no_teacher_video.append(course_id)
    set_no_teacher_video = set(final_no_teacher_video)
    no_teacher_video = len(set_no_teacher_video)

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1007"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #no_student_video = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    no_student_video = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                                    raise_on_error=False,
                                    index=index_name,
                                    timeout='1m')

    final_no_student_video = []
    for item in no_student_video:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_no_student_video.append(course_id)
    set_no_student_video = set(final_no_student_video)
    no_student_video = len(set_no_student_video)


    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1008"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #no_teacherandstudent_video = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    no_teacherandstudent_video = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                                    raise_on_error=False,
                                    index=index_name,
                                    timeout='1m')

    final_no_teacherandstudent_video = []
    for item in no_teacherandstudent_video:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_no_teacherandstudent_video.append(course_id)
    set_no_teacherandstudent_video = set(final_no_teacherandstudent_video)
    no_teacherandstudent_video = len(set_no_teacherandstudent_video)





    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1009"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }
    #algorithm_audioprocess_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    algorithm_audioprocess_failed = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False,
                                       index=index_name,
                                       timeout='1m')

    final_algorithm_audioprocess_failed = []
    for item in algorithm_audioprocess_failed:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_algorithm_audioprocess_failed.append(course_id)
    daily_algorithm_audioprocess_failed = set(final_algorithm_audioprocess_failed)
    algorithm_audioprocess_failed = len(daily_algorithm_audioprocess_failed)





    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1010"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }

    #rpctimeout = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    rpctimeout = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                                                 raise_on_error=False,
                                                 index=index_name,
                                                 timeout='1m')

    final_rpctimeout = []
    for item in rpctimeout:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_rpctimeout.append(course_id)
    daily_rpctimeout = set(final_rpctimeout)
    rpctimeout = len(daily_rpctimeout)



    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1011"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }
    #algorithm_videoprocess_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    algorithm_videoprocess_failed = helpers.scan(client=es, query=_query_name_contains, scroll='5m',
                              raise_on_error=False,
                              index=index_name,
                              timeout='1m')

    final_algorithm_videoprocess_failed = []
    for item in algorithm_videoprocess_failed:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_algorithm_videoprocess_failed.append(course_id)
    set_algorithm_videoprocess_failed = set(final_algorithm_videoprocess_failed)
    algorithm_videoprocess_failed = len(set_algorithm_videoprocess_failed)




    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1012"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }
    #audio_split_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']
    audio_split_failed = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False,
                                       index=index_name,
                                       timeout='1m')

    final_audio_split_failed = []
    for item in audio_split_failed:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_audio_split_failed.append(course_id)
    daily_audio_split_failed = set(final_audio_split_failed)
    audio_split_failed = len(daily_audio_split_failed)



    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(yesterday_timestamp) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1013"
                    }
                }]
            }
        }
    }
    #video_split_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    video_split_failed = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False,
                                      index=index_name,
                                      timeout='1m')

    final_video_split_failed = []
    for item in video_split_failed:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_video_split_failed.append(course_id)
    set_final_video_split_failed = set(final_video_split_failed)
    video_split_failed = len(set_final_video_split_failed)




    data_nocomplete = no_student_video + no_teacher_video + no_teacherandstudent_video

    # --------------------------------------------------------------------------------
    # process_total - audio_total_value - (
    #        algorithm_audioprocess_failed + audio_split_failed + asr_convert_fail) - data_nocomplete)
    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1003"
                    }
                }]
            }
        }
    }
    hithistoryaudio_total_value = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False,index=index_name, timeout='1m')

    final_historyaudio_total_value = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_historyaudio_total_value.append(course_id)
    list_historyaudio_total_value = set(final_historyaudio_total_value)
    historyaudio_total_value = len(list_historyaudio_total_value)

    # final_result_audio = []
    # for item in es_result:
    #     final_result_audio.append(item["_source"])
    # # historyvideo_total_value_course = set(final_result_video)
    # historyaudio_total_value = len(final_result_audio)

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1002"
                    }
                }]
            }
        }
    }

    hithistoryvideo_total_value = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False,index=index_name, timeout='1m')
    final_historyvideo_total_value = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_historyvideo_total_value.append(course_id)
    list_historyvideo_total_value = set(final_historyvideo_total_value)
    historyvideo_total_value= len(list_historyvideo_total_value)






    # final_result_video = []
    # for item in es_result:
    #     final_result_video.append(item["_source"])
    # # historyvideo_total_value_course = set(final_result_video)
    # historyvideo_total_value = len(final_result_video)

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1009"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }
    #historyalgorithm_audioprocess_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']
    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_historyalgorithm_audioprocess_failed = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_historyalgorithm_audioprocess_failed.append(course_id)
    list_historyalgorithm_audioprocess_failed = set(final_historyalgorithm_audioprocess_failed)
    historyalgorithm_audioprocess_failed = len(list_historyalgorithm_audioprocess_failed)


    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1012"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }
    #historyaudio_split_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']
    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_historyaudio_split_failed = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_historyaudio_split_failed.append(course_id)
    list_historyaudio_split_failed = set(final_historyaudio_split_failed)
    historyaudio_split_failed = len(list_historyaudio_split_failed)



    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1005"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }

    #historyasr_convert_fail = es.search(index=index_name, body=_query_name_contains)['hits']['total']
    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_list_historyasr_convert_fail = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_list_historyasr_convert_fail.append(course_id)
    list_historyasr_convert_fail = set(final_list_historyasr_convert_fail)
    historyasr_convert_fail = len(list_historyasr_convert_fail)


    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1013"
                    }
                }]
            }
        }
    }
    #historyvideo_split_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_historyvideo_split_failed = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_historyvideo_split_failed.append(course_id)
    list_historyvideo_split_failed = set(final_historyvideo_split_failed)
    historyvideo_split_failed = len(list_historyvideo_split_failed)



    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1011"
                    }
                }]
            }
        },
        "aggs": {
            "4": {
                "date_histogram": {
                    "interval": "30m",
                    "field": "@timestamp",
                    "min_doc_count": 0,
                    "extended_bounds": {
                        "min": "1548172800000",
                        "max": "1548259199999"
                    },
                    "format": "epoch_millis"
                },
                "aggs": {}
            }
        }
    }
    #historyalgorithm_videoprocess_failed = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_list_historyalgorithm_videoprocess_failed = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_list_historyalgorithm_videoprocess_failed.append(course_id)
    list_historyalgorithm_videoprocess_failed = set(final_list_historyalgorithm_videoprocess_failed)
    historyalgorithm_videoprocess_failed = len(list_historyalgorithm_videoprocess_failed)

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1006"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #historyno_teacher_video = es.search(index=index_name, body=_query_name_contains)['hits']['total']
    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_list_historyno_teacher_video = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_list_historyno_teacher_video.append(course_id)
    list_historyno_teacher_video = set(final_list_historyno_teacher_video)
    historyno_teacher_video = len(list_historyno_teacher_video)


    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1007"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #historyno_student_video = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_list_historyno_student_video = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_list_historyno_student_video.append(course_id)
    list_historyno_student_video = set(final_list_historyno_student_video)
    historyno_student_video = len(list_historyno_student_video)

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1008"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #historyno_teacherandstudent_video = es.search(index=index_name, body=_query_name_contains)['hits']['total']

    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_list_historyno_teacherandstudent_video = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_list_historyno_teacherandstudent_video.append(course_id)
    list_historyno_teacherandstudent_video = set(final_list_historyno_teacherandstudent_video)
    historyno_teacherandstudent_video = len(list_historyno_teacherandstudent_video)

    historydata_nocomplete = historyno_student_video + historyno_teacher_video + historyno_teacherandstudent_video

    _query_name_contains = {
        "size": 0,
        "query": {
            "bool": {
                "filter": [{
                    "range": {
                        "@timestamp": {
                            "gte": int(inceptiondate) * 1000,
                            "lte": int(today_timestamp) * 1000,
                            "format": "epoch_millis"
                        }
                    }
                }, {
                    "query_string": {
                        "analyze_wildcard": True,
                        "query": "code:1004"
                    }
                }]
            }
        }
        # ,
        # "aggs": {
        #     "4": {
        #         "date_histogram": {
        #             "interval": "30m",
        #             "field": "@timestamp",
        #             "min_doc_count": 0,
        #             "extended_bounds": {
        #                 "min": "1548172800000",
        #                 "max": "1548259199999"
        #             },
        #             "format": "epoch_millis"
        #         },
        #         "aggs": {}
        #     }
        # }
    }

    #historyaudio_drop_value = es.search(index=index_name, body=_query_name_contains)['hits']['total']
    es_result = helpers.scan(client=es, query=_query_name_contains, scroll='5m', raise_on_error=False, index=index_name,
                             timeout='1m')
    final_historyaudio_drop_value = []
    for item in es_result:
        courseStr = item["_source"]["message"]
        start_pos = courseStr.index("courseId")
        end_pos = courseStr.index(", modelType")
        course_id = courseStr[start_pos + 9:end_pos]
        final_historyaudio_drop_value.append(course_id)
    list_historyaudio_drop_value = set(final_historyaudio_drop_value)
    historyaudio_drop_value = len(list_historyaudio_drop_value)
    #视频全都小于10S错误码:1014
    courses_less_than_10s_history = len(get_course_list_by_code(1014,inceptiondate,today_timestamp,es))
    courses_less_than_10s_current = len(get_course_list_by_code(1014, yesterday_timestamp, today_timestamp,es))

    history_block_video = (daily_removeduplicate_totalcoursesize - historyvideo_total_value - (
            historyalgorithm_videoprocess_failed + historyvideo_split_failed) - historydata_nocomplete-courses_less_than_10s_history)

    history_block_audio = (daily_removeduplicate_totalcoursesize - historyaudio_total_value - (
            historyalgorithm_audioprocess_failed + historyaudio_split_failed + historyasr_convert_fail) - historydata_nocomplete - historyaudio_drop_value-courses_less_than_10s_history)


    template = """### {date} {project_name}运营日报
    
**课堂分析情况**:  
     
* 大海推送课堂总数:{process_total} 
* 数据完整课堂:{data_complete}
* 处理失败课堂:{course_processfailed}
* 当日返回大海课堂:{ret_couse_count}
* 当日积压课堂:{currentday_block} 

**历史积压详情**: 
* 历史积压返回课堂:{ret_yesterday_count}
* 历史积压视频:{history_block_video}
* 历史积压音频:{history_block_audio}

**数据不完整详情**:  

* 仅无老师视频:{no_teacher_video}
* 仅无学生视频:{no_student_video}
* 无老师＆无学生视频:{no_teacherandstudent_video} 

**处理失败详情**:  

* 下载失败:{download_fail_total}
* 音频丢弃:{audio_drop_count}
* asr转录失败:{asr_convert_fail}
* 音频算法处理失败:{algorithm_audioprocess_failed}
* 视频算法处理失败:{algorithm_videoprocess_failed}
* 线程通讯超时:{rpctimeout}
* 音频拆分失败:{audio_split_failed}
* 视频拆分失败:{video_split_failed} 
* 视频小于10S:{courses_less_than_10s_current}   
    
"""
    content = template.format(
        date=yesterday.strftime("%Y-%m-%d"),
        project_name=project_name,
        process_total=process_total,
        data_complete=(process_total - data_nocomplete),
        course_processfailed=algorithm_audioprocess_failed + audio_split_failed + asr_convert_fail + courses_less_than_10s_current,
        ret_couse_count=audio_total_value,
        ret_yesterday_count = yesterdayret,
        currentday_block=0 if (process_total - audio_total_value - (
                algorithm_audioprocess_failed + audio_split_failed + asr_convert_fail) - data_nocomplete -audio_drop_value-courses_less_than_10s_current) <= 0 else (
                process_total - audio_total_value - (
                    algorithm_audioprocess_failed + audio_split_failed + asr_convert_fail) - data_nocomplete - audio_drop_value - courses_less_than_10s_current),
        history_block_video=0 if history_block_video <= 0 else history_block_video,
        history_block_audio=0 if history_block_audio <= 0 else history_block_audio,
        no_teacher_video=no_teacher_video,
        no_student_video=no_student_video,
        no_teacherandstudent_video=no_teacherandstudent_video,

        download_fail_total=download_fail_total,
        audio_drop_count=audio_drop_value,
        asr_convert_fail=asr_convert_fail,
        algorithm_audioprocess_failed=algorithm_audioprocess_failed,
        algorithm_videoprocess_failed=algorithm_videoprocess_failed,
        rpctimeout=rpctimeout,
        audio_split_failed=audio_split_failed,
        video_split_failed=video_split_failed,
        courses_less_than_10s_current=courses_less_than_10s_current
    )

    print(content)
    # 测试
    # obj = DingTalk(
    #     'https://oapi.dingtalk.com/robot/send?access_token=d9f2091b4585622e4fbea7aae51862033c332fe1b0621da41a8fefbe3f69b57a')
    # obj.send_msg(content, [], at_all=True, msg_type="markdown",
    #             title="{date} 运营日报".format(date=yesterday.strftime("%Y-%m-%d")))

    # 线上
    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=3ce66d901d6e07a33fd00b67b706436b247520415a3028cef25cdba694ea4adf')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))

    # 发送到捣蛋群
    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=bf2c1c87cb843454140d9272f9b3a1953eb2232089c6ae919475575edf2d67fb')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))

    # 发送到总群
    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=c988c827d87c7742f945ad0417f6f77110863420bd445e45a5b0825f9a2b0729')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))

if __name__ == "__main__":
    send_daily_report()
