import requests
import pymongo
import datetime
import pandas as pd
import time
import numpy as np

start_date = datetime.datetime(2019, 6, 1)


class DingTalk:
    def __init__(self, url):
        """
        :param content: str
        :param url: str
        :param at_mobiles: list
        :param msg_type: str
        :param at_all: bool
        """
        self.url = url

    def send_msg(self, content, at_mobiles, msg_type='text', at_all=False, title=''):
        if msg_type == 'text':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'text': {'content': content}
            }
            return requests.post(self.url, json=data)
        if msg_type == 'markdown':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'markdown': {'title': title, 'text': content}
            }
            print(title, content)
            return requests.post(self.url, json=data)


# In[3]:
def send_daily_report(regex='.', after_time=datetime.datetime(2019, 3, 1), figsize=(20, 10)):
    today = datetime.date.today()
    today = datetime.datetime(today.year, today.month, today.day, 0, 0, 0)
    today_timestamp = int(time.mktime(today.timetuple()))
    yesterday = (today - datetime.timedelta(days=1))
    yesterday_timestamp = int(time.mktime(yesterday.timetuple()))
    client = pymongo.MongoClient(
        "mongodb://root:ikkyyu_2018@dds-2zeec8ea9a65d7841295-pub.mongodb.rds.aliyuncs.com:3717")
    db = client.admin
    result = db.m_ikkyyu
    # 学而思的正则匹配
    xes_regex = "xes"
    # 家长帮的正则匹配
    jzb_regex = "gaokaopai|aipic"
    # 云学习的正则匹配
    yxx_regex = 'ips'
    # 魔法学校的正则匹配
    mschool_regex = "tob"
    # time_df = pd.DataFrame(list(result.find({"source_url":{"$regex":regex},'receive_time':{"$gt":after_time}},{"receive_time":1,"_id":0})))
    # date_counter = Counter([i.date() for i in time_df.receive_time])
    # # print(date_counter)
    # print('过去七天的平均调用量',np.average(list(date_counter.values())[-8:-1]))
    # # print(list(date_counter.values()))
    # print('前一天的调用量',list(date_counter.values())[-1])
    # response_diff_df = pd.DataFrame(list(result.find({"source_url":{"$regex":regex},'receive_time':{"$gt":after_time}},{"response_time":1,"receive_time":1})))
    response_diff_df = pd.DataFrame(list(result.find({"source_url": {"$regex": regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1)}}, {"response_time": 1, "receive_time": 1})))

    response_diff_df['diff'] = response_diff_df.apply(
        lambda x: datetime.datetime.timestamp(x['response_time']) - datetime.datetime.timestamp(x['receive_time']),
        axis=1)
    # print(response_diff_df["diff"])
    daily_port_average = np.average(response_diff_df['diff'])
    daily_port_middle = np.percentile(response_diff_df['diff'], 50)
    daily_port_90 = np.percentile(response_diff_df['diff'], 90)
    daily_port_95 = np.percentile(response_diff_df['diff'], 95)
    daily_port_99 = np.percentile(response_diff_df['diff'], 99)
    daily_port_99_9 = np.percentile(response_diff_df['diff'], 99.9)
    daily_port_100 = np.percentile(response_diff_df['diff'], 100)
    if len([i for i in response_diff_df['diff'] if i > 1.15]) == 0:
        gt_one_point_five = 0
    else:
        gt_one_point_five = len([i for i in response_diff_df['diff'] if i > 1.15]) / len(response_diff_df['diff'])
    # response_alg_df = pd.DataFrame(list(result.find({"source_url":{"$regex":regex},'receive_time':{"$gt":after_time}},{'result.startTime':1,'result.endTime':1,"_id":0})))
    response_alg_df = pd.DataFrame(list(result.find({"source_url": {"$regex": regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1)}},
                                                    {'result.startTime': 1, 'result.endTime': 1, "_id": 0})))

    def get_diff(x):
        try:
            return x['result']['endTime'] - x['result']['startTime']
        except:
            return 0

    response_alg_df['diff'] = response_alg_df.apply(get_diff, axis=1)
    today_algorithm_average = np.average(response_alg_df['diff'])
    today_algorithm_middle = np.percentile(response_alg_df['diff'], 50)
    today_algorithm_90 = np.percentile(response_alg_df['diff'], 90)
    today_algorithm_95 = np.percentile(response_alg_df['diff'], 95)
    today_algorithm_99 = np.percentile(response_alg_df['diff'], 99)
    today_algorithm_99_9 = np.percentile(response_alg_df['diff'], 99.9)
    today_algorithm_100 = np.percentile(response_alg_df['diff'], 100)
    if len([i for i in response_diff_df['diff'] if i > 1]) == 0:
        gt_one_point = 0
    else:
        gt_one_point = len([i for i in response_diff_df['diff'] if i > 1]) / len(response_diff_df['diff'])
    # In[7]:
    print("___________________________6月1号之后数据____________________________")
    count = 0
    count_no_titile = result.count_documents(
        {"source_url": {"$regex": "."}, 'receive_time': {"$gt": start_date}, "result.questionImgs": {"$size": 0}}, {})
    if count_no_titile == 0:
        date_1_2_rate = 0
    else:
        count = result.count_documents(
            {"source_url": {"$regex": "."}, 'receive_time': {"$gt": start_date}}, {})
        date_1_2_rate = count_no_titile / count
        print(date_1_2_rate)

    xes_count = 0
    xes_count_no_title = result.count_documents(
        {"source_url": {"$regex": "xes.+?201\d{5}"}, 'receive_time': {"$gt": start_date},
         "result.questionImgs": {"$size": 0}}, {})
    if xes_count_no_title == 0:
        xes_1_2_rate = 0
    else:
        xes_count = result.count_documents(
            {"source_url": {"$regex": "xes.+?201\d{5}"}, 'receive_time': {"$gt": start_date}}, {})
        xes_1_2_rate = xes_count_no_title / xes_count
        print(xes_1_2_rate)

    jzb_count = 0
    jzb_count_no_title = result.count_documents(
        {"source_url": {"$regex": jzb_regex}, 'receive_time': {"$gt": start_date},
         "result.questionImgs": {"$size": 0}},
        {})
    if jzb_count_no_title == 0:
        jzb_1_2_rate = 0
    else:
        jzb_count = result.count_documents(
            {"source_url": {"$regex": jzb_regex}, 'receive_time': {"$gt": start_date}},
            {})
        jzb_1_2_rate = jzb_count_no_title / jzb_count
        print(jzb_1_2_rate)

    yxx_count = 0
    yxx_count_no_title = result.count_documents(
        {"source_url": {"$regex": "ips.+?201\d{5}"}, 'receive_time': {"$gt": start_date},
         "result.questionImgs": {"$size": 0}}, {})
    if yxx_count_no_title == 0:
        yxx_1_2_rate = 0
        print(yxx_1_2_rate)
    else:
        yxx_count = result.count_documents(
            {"source_url": {"$regex": "ips.+?201\d{5}"}, 'receive_time': {"$gt": start_date}}, {})
        yxx_1_2_rate = yxx_count_no_title / yxx_count
        print(yxx_1_2_rate)

    mschool_count = 0
    mschool_count_no_title = result.count_documents(
        {"source_url": {"$regex": "tob.+?201\d{5}"}, 'receive_time': {"$gt": start_date},
         "result.questionImgs": {"$size": 0}}, {})
    if mschool_count_no_title == 0:
        mschoot_1_2_rate = 0
    else:
        mschool_count = result.count_documents(
            {"source_url": {"$regex": "tob.+?201\d{5}"}, 'receive_time': {"$gt": start_date}}, {})
        mschoot_1_2_rate = mschool_count_no_title / mschool_count
        print(mschoot_1_2_rate)

    print("___________________________周数据____________________________")

    count_weekly = 0
    count_weekly_no_title = result.count_documents({"source_url": {"$regex": "."}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=7), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if count_weekly_no_title == 0:
        count_weekly_rate = 0
        print(count_weekly_rate)
    else:
        count_weekly = result.count_documents({"source_url": {"$regex": "."}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=7), "$lt":today}}, {})
        count_weekly_rate = count_weekly_no_title / count_weekly
        print(count_weekly_rate)

    xes_count_weekly = 0
    xes_count_weekly_no_title = result.count_documents({"source_url": {"$regex": "xes.+?201\d{5}"}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=7), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if xes_count_weekly_no_title == 0:
        xes_weekly_rate = 0
        print(xes_weekly_rate)
    else:
        xes_count_weekly = result.count_documents({"source_url": {"$regex": "xes.+?201\d{5}"}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=7), "$lt":today}}, {})
        xes_weekly_rate = xes_count_weekly_no_title / xes_count_weekly
        print(xes_weekly_rate)

    jzb_count_weekly = 0
    jzb_count_weekly_no_title = result.count_documents({"source_url": {"$regex": jzb_regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=7), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if jzb_count_weekly_no_title == 0:
        jzb_weekly_rate = 0
        print(jzb_weekly_rate)
    else:
        jzb_count_weekly = result.count_documents({"source_url": {"$regex": jzb_regex}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=7), "$lt":today}}, {})
        jzb_weekly_rate = jzb_count_weekly_no_title / jzb_count_weekly
        print(jzb_weekly_rate)

    yxx_count_weekly = 0
    yxx_count_weekly_no_title = result.count_documents({"source_url": {"$regex": "ips.+?201\d{5}"}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=7), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if yxx_count_weekly_no_title == 0:
        yxx_weekly_rate = 0
        print(yxx_weekly_rate)
    else:
        yxx_count_weekly = result.count_documents({"source_url": {"$regex": "ips.+?201\d{5}"}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=7), "$lt":today}}, {})
        yxx_weekly_rate = yxx_count_weekly_no_title / yxx_count_weekly
        print(yxx_weekly_rate)

    mschool_count_weekly = 0
    mschool_count_weekly_no_title = result.count_documents({"source_url": {"$regex": "tob.+?201\d{5}"}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=7), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if mschool_count_weekly_no_title == 0:
        mschool_weekly_rate = 0
        print(mschool_weekly_rate)
    else:
        mschool_count_weekly = result.count_documents({"source_url": {"$regex": "tob.+?201\d{5}"}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=7), "$lt":today}}, {})
        mschool_weekly_rate = mschool_count_weekly_no_title / mschool_count_weekly
        print(mschool_weekly_rate)

    print("_________________________日数据______________________________")
    count_daily = 0
    count_daily_no_title = result.count_documents({"source_url": {"$regex": "."}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if count_daily_no_title == 0:
        count_daily_rate = 0
    else:
        count_daily = result.count_documents({"source_url": {"$regex": "."}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=1), "$lt":today}}, {})
        count_daily_rate = count_daily_no_title / count_daily
        print(count_daily_rate)

    xes_count_daily = 0
    xes_count_daily_no_title = result.count_documents({"source_url": {"$regex": xes_regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if xes_count_daily_no_title == 0:
        xes_daily_rate = 0
    else:
        xes_count_daily = result.count_documents({"source_url": {"$regex": xes_regex}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=1), "$lt":today}}, {})
        xes_daily_rate = xes_count_daily_no_title / xes_count_daily
        print(xes_daily_rate)

    jzb_count_daily = 0
    jzb_count_daily_no_title = result.count_documents({"source_url": {"$regex": jzb_regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if jzb_count_daily_no_title == 0:
        jzb_daily_rate = 0
    else:
        jzb_count_daily = result.count_documents({"source_url": {"$regex": jzb_regex}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=1), "$lt":today}}, {})
        jzb_daily_rate = jzb_count_daily_no_title / jzb_count_daily
        print(jzb_daily_rate)

    yxx_count_daily = 0
    yxx_count_daily_no_title = result.count_documents({"source_url": {"$regex": yxx_regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if yxx_count_daily_no_title == 0:
        yxx_daily_rate = 0
    else:
        yxx_count_daily = result.count_documents({"source_url": {"$regex": yxx_regex}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=1), "$lt":today}}, {})
        yxx_daily_rate = yxx_count_daily_no_title / yxx_count_daily
        print(yxx_daily_rate)

    mschool_count_daily = 0
    mschool_count_daily_no_title = result.count_documents({"source_url": {"$regex": mschool_regex}, 'receive_time': {
        "$gt": today - datetime.timedelta(days=1), "$lt":today}, "result.questionImgs": {"$size": 0}}, {})
    if mschool_count_daily_no_title == 0:
        mschool_daily_rate = 0
    else:
        mschool_count_daily = result.count_documents({"source_url": {"$regex": mschool_regex}, 'receive_time': {
            "$gt": today - datetime.timedelta(days=1), "$lt":today}}, {})
        mschool_daily_rate = mschool_count_daily_no_title / mschool_count_daily
        print(mschool_daily_rate)

    template = """#### {date} 00:00 - 24:00  一休解题运营分析日报
**今日接口数据**
- 响应时间的平均值：{daily_port_average}
- 响应时间的中位数: {daily_port_middle}
- 响应90%的时间: {daily_port_90}
- 响应95%的时间: {daily_port_95}
- 响应99%的时间: {daily_port_99}
- 响应99.9%的时间: {daily_port_99_9}
- 响应100%的时间: {daily_port_100}
- 响应时间1.15s以上的比例: {gt_one_point_five}%
- - -
**今日算法模型数据**
- 响应时间的平均值: {today_algorithm_average}
- 响应时间的中位数: {today_algorithm_middle}
- 响应90%时间: {today_algorithm_90}
- 响应95%时间: {today_algorithm_95}
- 响应99%时间: {today_algorithm_99}
- 响应99.9%时间: {today_algorithm_99_9}
- 响应100%时间: {today_algorithm_100}
- 响应时间1s以上的比例: {gt_one_point}%
- - -
**从19年6月1日开始的数据**
- 总调用量: {count}
- 学而思APP调用量: {xes_count}
- 家长帮调用量: {jzb_count}
- 云学习调用量: {yxx_count}
- 未来魔法校调用量: {mschool_count}
- 总无题目占比: {date_1_2_rate}%
- 学而思APP无题目占比: {xes_1_2_rate}%
- 家长帮无题目占比: {jzb_1_2_rate}%
- 云学习无题目占比: {yxx_1_2_rate}%
- 未来魔法校无题目占比: {mschoot_1_2_rate}%
- - -
**本周数据**
- 总调用量: {count_weekly}
- 学而思APP调用量: {xes_count_weekly}
- 家长帮调用量: {jzb_count_weekly}
- 云学习调用量: {yxx_count_weekly}
- 未来魔法校调用量: {mschool_count_weekly}
- 总无题目占比: {count_weekly_rate}%
- 学而思APP无题目占比: {xes_weekly_rate}%
- 家长帮无题目占比: {jzb_weekly_rate}%
- 云学习无题目占比: {yxx_weekly_rate}%
- 未来魔法校无题目占比: {mschool_weekly_rate}%
- - -
**今日数据**
- 总调用量: {count_daily}
- 学而思APP调用量: {xes_count_daily}
- 家长帮调用量: {jzb_count_daily}
- 云学习调用量: {yxx_count_daily}
- 未来魔法校调用量: {mschool_count_daily}
- 总无题目占比: {count_daily_rate}%
- 学而思APP无题目占比: {xes_daily_rate}%
- 家长帮无题目占比: {jzb_daily_rate}%
- 云学习无题目占比: {yxx_daily_rate}%
- 未来魔法校无题目占比: {mschool_daily_rate}%
"""
    content = template.format(
        date=yesterday.strftime("%Y-%m-%d"),
        daily_port_average=round(daily_port_average, 4),
        daily_port_90=round(daily_port_90, 4),
        daily_port_95=round(daily_port_95, 4),
        daily_port_99=round(daily_port_99, 4),
        daily_port_99_9=round(daily_port_99_9, 4),
        daily_port_100=round(daily_port_100, 4),
        daily_port_middle=round(daily_port_middle, 4),
        gt_one_point_five=round(gt_one_point_five * 100, 3),
        today_algorithm_average=round(today_algorithm_average, 4),
        today_algorithm_middle=round(today_algorithm_middle, 4),
        today_algorithm_90=round(today_algorithm_90, 4),
        today_algorithm_95=round(today_algorithm_95, 4),
        today_algorithm_99=round(today_algorithm_99, 4),
        today_algorithm_99_9=round(today_algorithm_99_9, 4),
        today_algorithm_100=round(today_algorithm_100, 4),
        gt_one_point=round(gt_one_point * 100, 3),
        date_1_2_rate=round(date_1_2_rate * 100, 4),
        xes_1_2_rate=round(xes_1_2_rate * 100, 4),
        jzb_1_2_rate=round(jzb_1_2_rate * 100, 4),
        yxx_1_2_rate=round(yxx_1_2_rate * 100, 4),
        mschoot_1_2_rate=round(mschoot_1_2_rate * 100, 4),
        count_weekly_rate=round(count_weekly_rate * 100, 4),
        xes_weekly_rate=round(xes_weekly_rate * 100, 4),
        jzb_weekly_rate=round(jzb_weekly_rate * 100, 4),
        yxx_weekly_rate=round(yxx_weekly_rate * 100, 4),
        mschool_weekly_rate=round(mschool_weekly_rate * 100, 4),
        count_daily_rate=round(count_daily_rate * 100, 4),
        xes_daily_rate=round(xes_daily_rate * 100, 4),
        jzb_daily_rate=round(jzb_daily_rate * 100, 4),
        yxx_daily_rate=round(yxx_daily_rate * 100, 4),
        mschool_daily_rate=round(mschool_daily_rate * 100, 4),
        count=round(count, 4),
        xes_count=round(xes_count, 4),
        jzb_count=round(jzb_count, 4),
        yxx_count=round(yxx_count, 4),
        mschool_count=round(mschool_count, 4),
        count_weekly=round(count_weekly, 4),
        xes_count_weekly=round(xes_count_weekly, 4),
        jzb_count_weekly=round(jzb_count_weekly, 4),
        yxx_count_weekly=round(yxx_count_weekly, 4),
        mschool_count_weekly=round(mschool_count_weekly, 4),
        count_daily=round(count_daily, 4),
        xes_count_daily=round(xes_count_daily, 4),
        jzb_count_daily=round(jzb_count_daily, 4),
        yxx_count_daily=round(yxx_count_daily, 4),
        mschool_count_daily=round(mschool_count_daily, 4)
    )
    # obj = DingTalk('https://oapi.dingtalk.com/robot/send?access_token=ffd0a651a72aac3e767892d62d7cf057ba6c1704ce2c4ac01fbaf57d5789685f')
    obj = DingTalk('https://oapi.dingtalk.com/robot/send?access_token=67fa072cbeb75e70b64da00dde38d6117ba765c44e68c80ad33a5b97c6c021b3')  # prod
    # obj = DingTalk(
    #     'https://oapi.dingtalk.com/robot/send?access_token=d357da381ca3c64629f17f2490777b454b211cf0ecf167ad4691179930e9de47')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))
    template = """#### {date} 00:00 - 24:00  一休解题运营分析日报
**从19年6月1日开始的数据**
- 总调用量: {count}
- 学而思APP调用量: {xes_count}
- 家长帮调用量: {jzb_count}
- 云学习调用量: {yxx_count}
- 未来魔法校调用量: {mschool_count}
- - -
**今日数据**
- 总调用量: {count_daily}
- 学而思APP调用量: {xes_count_daily}
- 家长帮调用量: {jzb_count_daily}
- 云学习调用量: {yxx_count_daily}
- 未来魔法校调用量: {mschool_count_daily}
- - -
**今日接口数据**
- P95响应时间: {daily_port_95}
- P99响应时间: {daily_port_99}
- - -
**今日算法模型数据**
- P95响应时间: {today_algorithm_95}
- P99响应时间: {today_algorithm_99}
"""
    content = template.format(
        count=round(count, 4),
        xes_count=round(xes_count, 4),
        jzb_count=round(jzb_count, 4),
        yxx_count=round(yxx_count, 4),
        mschool_count=round(mschool_count, 4),
        count_daily=round(count_daily, 4),
        xes_count_daily=round(xes_count_daily, 4),
        jzb_count_daily=round(jzb_count_daily, 4),
        yxx_count_daily=round(yxx_count_daily, 4),
        mschool_count_daily=round(mschool_count_daily, 4),
        daily_port_95=round(daily_port_95, 4),
        daily_port_99=round(daily_port_99, 4),
        today_algorithm_95=round(today_algorithm_95, 4),
        today_algorithm_99=round(today_algorithm_99, 4),
        date=yesterday.strftime("%Y-%m-%d"),
        # daily_port_90=round(daily_port_90, 4),
        # gt_one_point_five=round(gt_one_point_five * 100, 3),
        # today_algorithm_90=round(today_algorithm_90, 4),
        # gt_one_point=round(gt_one_point * 100, 3),
        # date_1_2_rate=round(date_1_2_rate * 100, 4),
        # xes_1_2_rate=round(xes_1_2_rate * 100, 4),
        # jzb_1_2_rate=round(jzb_1_2_rate * 100, 4),
        # yxx_1_2_rate=round(yxx_1_2_rate * 100, 4),
        # mschoot_1_2_rate=round(mschoot_1_2_rate * 100, 4),
        # count_weekly_rate=round(count_weekly_rate * 100, 4),
        # xes_weekly_rate=round(xes_weekly_rate * 100, 4),
        # jzb_weekly_rate=round(jzb_weekly_rate * 100, 4),
        # yxx_weekly_rate=round(yxx_weekly_rate * 100, 4),
        # mschool_weekly_rate=round(mschool_weekly_rate * 100, 4),
        # count_daily_rate=round(count_daily_rate * 100, 4),
        # xes_daily_rate=round(xes_daily_rate * 100, 4),
        # jzb_daily_rate=round(jzb_daily_rate * 100, 4),
        # yxx_daily_rate=round(yxx_daily_rate * 100, 4),
        # mschool_daily_rate=round(mschool_daily_rate * 100, 4),
        # count_weekly=round(count_weekly, 4),
        # xes_count_weekly=round(xes_count_weekly, 4),
        # jzb_count_weekly=round(jzb_count_weekly, 4),
        # yxx_count_weekly=round(yxx_count_weekly, 4),
        # mschool_count_weekly=round(mschool_count_weekly, 4),

    )
    obj = DingTalk('https://oapi.dingtalk.com/robot/send?access_token=4a808e0681827ef2174154b1c3cf394506890a5c846821c8225484703ad4ba2f') # prod
    # obj = DingTalk('https://oapi.dingtalk.com/robot/send?access_token=67fa072cbeb75e70b64da00dde38d6117ba765c44e68c80ad33a5b97c6c021b3')
    # obj = DingTalk(
    #     'https://oapi.dingtalk.com/robot/send?access_token=d357da381ca3c64629f17f2490777b454b211cf0ecf167ad4691179930e9de47')  # gehang

    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))

    # 发送到总群
    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=c988c827d87c7742f945ad0417f6f77110863420bd445e45a5b0825f9a2b0729')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))


if __name__ == "__main__":
    send_daily_report()
