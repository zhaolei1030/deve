import datetime
import time
import requests
from elasticsearch import Elasticsearch

class DingTalk:
    def __init__(self, url):
        """
        :param content: str
        :param url: str
        :param at_mobiles: list
        :param msg_type: str
        :param at_all: bool
        """
        self.url = url

    def send_msg(self, content, at_mobiles, msg_type='text', at_all=False, title=''):
        if msg_type == 'text':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'text': {'content': content}
            }
            return requests.post(self.url, json=data)
        if msg_type == 'markdown':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'markdown': {'title': title, 'text': content}
            }
            print(title, content)
            return requests.post(self.url, json=data)


def send_daily_report():
    today = datetime.date.today()  # 获取当前日期
    today_timestamp = int(time.mktime(today.timetuple()))
    print(today_timestamp)
    yesterday = (today - datetime.timedelta(days=1))
    yesterday_timestamp = int(time.mktime(yesterday.timetuple()))
    print(yesterday_timestamp)
    # today_timestamp=1550847601
    # yesterday_timestamp =1550764801
    project_name = "GES调用量"
    index_name = "api-return-output-prod*"
    # 线上
    es = Elasticsearch([{'host': '221.122.130.6', 'port': 9200}],http_auth=('se','se@paas_prod'))

    #aggratiation appKey to get all business client process totall
    _query_aggs_appKey_contains = {
        "size": 0,
        "aggs": {
            "apiId": {
                "terms": {
                    "field": "apiId.keyword",
                    "size": 100
                },
                "aggs": {
                    "accountId": {
                        "terms": {
                            "field": "accountId.keyword",
                            "size": 100
                        },
                        "aggs": {
                            "durations": {
                                "sum": {
                                    "field": "duration"
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    _query_yesterday_to_today_contains = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_all": {}
                        },
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": int(yesterday_timestamp) * 1000,
                                    "lte": int(today_timestamp) * 1000,
                                    "format": "epoch_millis"
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "apiId": {
                    "terms": {
                        "field": "apiId.keyword",
                        "size": 100
                    },
                    "aggs": {
                        "accountId": {
                            "terms": {
                                "field": "accountId.keyword",
                                "size": 100
                            },
                            "aggs": {
                                "durations": {
                                    "sum": {
                                        "field": "duration"
                                    }
                                }
                            }
                        }
                    }
                }
            }
     }

    _query_yesterday_success_calls= {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_all": {}
                        },
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": int(yesterday_timestamp) * 1000,
                                    "lte": int(today_timestamp) * 1000,
                                    "format": "epoch_millis"
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "apiId": {
                    "terms": {
                        "field": "apiId.keyword",
                        "size": 100
                    },
                    "aggs": {
                        "accountId": {
                            "terms": {
                                "field": "accountId.keyword",
                                "size": 100
                            },
                            "aggs": {
                                "returncode": {
                                    "terms": {
                                        "field": "code.keyword"
                                    }
                                }
                            }
                        }
                    }
                }
            }
     }


    # totals_by_appKey= es.search(index=index_name, body=_query_aggs_appKey_contains)['aggregations']["appKey"]["buckets"]
    totals_by_appKey = es.search(index=index_name, body=_query_aggs_appKey_contains)['aggregations']["apiId"][
        "buckets"]

    #print(totals_by_appKey)
    totals_yesterday_today= es.search(index=index_name, body=_query_yesterday_to_today_contains)['aggregations']["apiId"]["buckets"]
    #print(totals_yesterday_today)

    success_call_yesterday= es.search(index=index_name, body=_query_yesterday_success_calls)['aggregations']["apiId"]["buckets"]


    # init all parameters:
    qq_process_total= 0
    qq_duration_total=0

    qq_test_process_total = 0
    qq_test_duration_total = 0

    zhikang_online_process_total = 0
    zhikang_online_duration_total=0
    zhikang_online_textdetect_process_total=0
    zhikang_offline_duration_total=0
    zhikang_offline_bodydetect_process_total=0
    zhikang_online_textdetect_process_total=0
    zhikang_offline_textdetect_process_total=0
    zhikang_online_bodydetect_process_total=0

    qq_yesterday_process_total = 0
    qq_yesterday_success_process=0
    qq_yesterday_duration_total = 0
    qq_multimode_process_total = 0
    qq_yesterday_multimode_process_total = 0
    qq_yesterday_multimode_success_process = 0
    qq_talkdetect_process_total=0
    qq_yesterday_talkdetect_process_total =0
    qq_yesterday_talkdetect_success_process = 0
    qq_logodetect_process_total = 0
    qq_yesterday_logodetect_process_total =0
    qq_yesterday_logodetect_success_process =0
    qq_exposedetect_process_total=0
    qq_yesterday_exposedetect_process_total=0
    qq_yesterday_exposedetect_success_process=0
    qq_facedetect_process_total=0
    qq_yesterday_facedetect_process_total=0
    qq_yesterday_facedetect_success_process=0

    qq_textdetect_process_total=0
    qq_yesterday_textdetect_process_total=0
    qq_yesterday_textdetect_success_process=0

    qq_hudong_process_total=0
    qq_yesterday_hudong_process_total=0
    qq_yesterday_hudong_success_process=0


    qq_test_yesterday_process_total = 0
    qq_test_yesterday_duration_total = 0

    zhikang_offline_process_total = 0
    zhikang_offline_yesterday_process_total = 0
    zhikang_offline_yesterday_success_process =0
    zhikang_offline_yesterday_duration_total = 0
    zhikang_offline_yesterday_bodydetect_process_total = 0
    zhikang_offline_yesterday_bodydetect_success_process =0
    zhikang_offline_yesterday_textdetect_process_total = 0
    zhikang_offline_yesterday_textdetect_success_process = 0
    zhikang_offline_yesterday_multimode_process_total=0
    zhikang_offline_yesterday_multimode_success_process=0
    zhikang_offline_multimode_process_total = 0


    zhikang_online_talkdetect_process_total=0
    zhikang_online_yesterday_talkdetect_process_total=0
    zhikang_online_yesterday_talkdetect_success_process=0

    zhikang_online_yesterday_process_total = 0
    zhikang_online_yesterday_success_process = 0
    zhikang_online_yesterday_duration_total = 0
    zhikang_online_yesterday_bodydetect_process_total = 0
    zhikang_online_yesterday_bodydetect_success_process = 0
    zhikang_online_yesterday_textdetect_process_total = 0
    zhikang_online_yesterday_textdetect_success_process = 0
    zhikang_online_yesterday_multimode_process_total = 0
    zhikang_online_yesterday_multimode_success_process = 0
    zhikang_online_multimode_process_total=0

    for item in totals_by_appKey:
         #qingqing

         if item['key'] == "9":
             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_process_total = sub_item['doc_count']
                     qq_duration_total = sub_item['durations']['value']


                 if sub_item['key'] == '7':
                     zhikang_online_process_total = sub_item['doc_count']
                     zhikang_online_duration_total=sub_item['durations']['value']

                 if sub_item['key'] == '8':
                     zhikang_offline_process_total = sub_item['doc_count']
                     zhikang_offline_duration_total = sub_item['durations']['value']

         if item['key'] == "11":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '7':
                     zhikang_online_bodydetect_process_total = sub_item['doc_count']

                 if sub_item['key'] == '8':
                     zhikang_offline_bodydetect_process_total = sub_item['doc_count']

         if item['key'] == "10":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_textdetect_process_total=sub_item['doc_count']

                 if sub_item['key'] == '7':
                     zhikang_online_textdetect_process_total=sub_item['doc_count']

                 if sub_item['key'] == '8':
                     zhikang_offline_textdetect_process_total=sub_item['doc_count']

         if item['key'] == "12":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_multimode_process_total=sub_item['doc_count']

                 if sub_item['key'] == '7':
                     zhikang_online_multimode_process_total=sub_item['doc_count']

                 if sub_item['key'] == '8':
                     zhikang_offline_multimode_process_total=sub_item['doc_count']


         if item['key'] == "13":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_hudong_process_total=sub_item['doc_count']



         if item['key'] == "15":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_talkdetect_process_total=sub_item['doc_count']

                 if sub_item['key'] == '7':
                     zhikang_online_talkdetect_process_total=sub_item['doc_count']

         if item['key'] == "20":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_facedetect_process_total=sub_item['doc_count']


         if item['key'] == "24":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_exposedetect_process_total=sub_item['doc_count']


         if item['key'] == "26":

             for sub_item in item['accountId']['buckets']:

                 if sub_item['key'] == '5':
                     qq_logodetect_process_total=sub_item['doc_count']




    # handle special case
    if len(totals_yesterday_today) != 0:
      for item in totals_yesterday_today:

        if item['key'] == "9":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_process_total = sub_item['doc_count']
                    qq_yesterday_duration_total = sub_item['durations']['value']

                if sub_item['key'] == '7':
                    zhikang_online_yesterday_duration_total = sub_item['durations']['value']
                    zhikang_online_yesterday_process_total = sub_item['doc_count']

                if sub_item['key'] == '8':
                    zhikang_offline_yesterday_duration_total = sub_item['durations']['value']
                    zhikang_offline_yesterday_process_total = sub_item['doc_count']

        if item['key'] == "11":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '7':
                    zhikang_online_yesterday_bodydetect_process_total = sub_item['doc_count']

                if sub_item['key'] == '8':
                    zhikang_offline_yesterday_bodydetect_process_total = sub_item['doc_count']


        if item['key'] == "10":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_textdetect_process_total = sub_item['doc_count']

                if sub_item['key'] == '7':
                    zhikang_online_yesterday_textdetect_process_total = sub_item['doc_count']

                if sub_item['key'] == '8':
                    zhikang_offline_yesterday_textdetect_process_total = sub_item['doc_count']

        if item['key'] == "12":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_multimode_process_total = sub_item['doc_count']

                if sub_item['key'] == '7':
                    zhikang_online_yesterday_multimode_process_total = sub_item['doc_count']

                if sub_item['key'] == '8':
                    zhikang_offline_yesterday_multimode_process_total = sub_item['doc_count']

        if item['key'] == "13":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_hudong_process_total = sub_item['doc_count']


        if item['key'] == "15":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_talkdetect_process_total = sub_item['doc_count']

                if sub_item['key'] == '7':
                    zhikang_online_yesterday_talkdetect_process_total= sub_item['doc_count']

        if item['key'] == "20":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_facedetect_process_total = sub_item['doc_count']

        if item['key'] == "24":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_exposedetect_process_total = sub_item['doc_count']


        if item['key'] == "26":

            for sub_item in item['accountId']['buckets']:

                if sub_item['key'] == '5':
                    qq_yesterday_logodetect_process_total = sub_item['doc_count']



    if len(success_call_yesterday) != 0:

        for item in success_call_yesterday:

            if item['key'] == "9":

                for sub_item in item['accountId']['buckets']:

                    if sub_item['key'] == '5':

                        for _code in sub_item['returncode']['buckets']:
                               if _code['key'] == "20000":
                                   qq_yesterday_success_process = _code['doc_count']
                                   break

                    if sub_item['key'] == '7':

                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_online_yesterday_success_process = _code['doc_count']
                                break

                    if sub_item['key'] == '8':

                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_offline_yesterday_success_process = _code['doc_count']
                                break

            if item['key'] == "11":

                for sub_item in item['accountId']['buckets']:

                    if sub_item['key'] == '7':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_online_yesterday_bodydetect_success_process = _code['doc_count']
                                break

                    if sub_item['key'] == '8':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_offline_yesterday_bodydetect_success_process = _code['doc_count']
                                break


            if item['key'] == "10":

                for sub_item in item['accountId']['buckets']:

                    if sub_item['key'] == '5':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                qq_yesterday_textdetect_success_process = _code['doc_count']
                                break

                    if sub_item['key'] == '7':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_online_yesterday_textdetect_success_process = _code['doc_count']
                                break

                    if sub_item['key'] == '8':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_offline_yesterday_textdetect_success_process = _code['doc_count']
                                break

            if item['key'] == "12":
                for sub_item in item['accountId']['buckets']:
                    if sub_item['key'] == '5':
                        for _code in sub_item['returncode']['buckets']:
                               if _code['key'] == "20000":
                                   qq_yesterday_multimode_success_process = _code['doc_count']
                                   break

                    if sub_item['key'] == '7':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_online_yesterday_multimode_success_process = _code['doc_count']
                                break

                    if sub_item['key'] == '8':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_offline_yesterday_multimode_success_process = _code['doc_count']
                                break

            if item['key'] == "13":
                for sub_item in item['accountId']['buckets']:
                    if sub_item['key'] == '5':
                        for _code in sub_item['returncode']['buckets']:
                               if _code['key'] == "20000":
                                   qq_yesterday_hudong_success_process = _code['doc_count']
                                   break


            if item['key'] == "15":
                for sub_item in item['accountId']['buckets']:
                    if sub_item['key'] == '5':
                        for _code in sub_item['returncode']['buckets']:
                               if _code['key'] == "20000":
                                   qq_yesterday_talkdetect_success_process = _code['doc_count']
                                   break

                    if sub_item['key'] == '7':
                        for _code in sub_item['returncode']['buckets']:
                            if _code['key'] == "20000":
                                zhikang_online_yesterday_talkdetect_success_process = _code['doc_count']
                                break

            if item['key'] == "24":
                for sub_item in item['accountId']['buckets']:
                    if sub_item['key'] == '5':
                        for _code in sub_item['returncode']['buckets']:
                               if _code['key'] == "20000":
                                   qq_yesterday_exposedetect_success_process = _code['doc_count']
                                   break

            if item['key'] == "26":
                for sub_item in item['accountId']['buckets']:
                    if sub_item['key'] == '5':
                        for _code in sub_item['returncode']['buckets']:
                               if _code['key'] == "20000":
                                   qq_yesterday_logodetect_success_process = _code['doc_count']
                                   break


#     template = """### {date} {project_name}运营日报
# **轻轻**：
# - 昨日ASR调用次数：{qq_yesterday_process_total}
# - 昨日ASR调用时长: {qq_yesterday_duration_total} 小时
# - 累计ASR调用次数: {qq_process_total}
# - 累计ASR调用时长: {qq_duration_total} 小时
#
# **智康线下**:
#
# - 昨日ASR调用次数: {zhikang_offline_yesterday_process_total}
# - 昨日ASR调用时长: {zhikang_offline_yesterday_duration_total} 小时
# - 累计ASR调用时长: {zhikang_offline_duration_total} 小时
# - 昨日人体检测调用次数: {zhikang_offline_yesterday_bodydetect_process_total}
# - 累计人体检测调用次数: {zhikang_offline_bodydetect_process_total}
# - 昨日文本检测调用次数: {zhikang_offline_yesterday_textdetect_process_total}
# - 累计文本检测调用次数: {zhikang_offline_textdetect_process_total}
#
# **智康线上**:
#
# - 昨日ASR调用次数: {zhikang_online_yesterday_process_total}
# - 昨日ASR调用时长: {zhikang_online_yesterday_duration_total} 小时
# - 累计ASR调用时长: {zhikang_online_duration_total} 小时
# - 昨日人体检测调用次数: {zhikang_online_yesterday_bodydetect_process_total}
# - 累计人体检测调用次数:{zhikang_online_bodydetect_process_total}
# - 昨日文本检测调用次数:{zhikang_online_yesterday_textdetect_process_total}
# - 累计文本检测调用次数:{zhikang_online_textdetect_process_total}
# """

    template = """### {date} {project_name}运营日报
**轻轻**：
（昨日调用/成功次数/成功率/累计调用）
- ASR次数:&nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_process_total} / {qq_yesterday_success_process} / {qq_yesterday_success_precent}% / {qq_process_total}
- ASR时长:&nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_duration_total} / - / - / {qq_duration_total}
- 文本关键词:&nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_textdetect_process_total} / {qq_yesterday_textdetect_success_process} / {qq_yesterday_textdetect_success_precent}% / {qq_textdetect_process_total}
- 多模态: &nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_multimode_process_total} / {qq_yesterday_multimode_success_process} / {qq_yesterday_multimode_success_precent}% / {qq_multimode_process_total}
- 闲聊识别:&nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_talkdetect_process_total} / {qq_yesterday_talkdetect_success_process} / {qq_yesterday_talkdetect_success_precent}% / {qq_talkdetect_process_total}
- 互动质量:&nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_hudong_process_total} / {qq_yesterday_hudong_success_process} / {qq_yesterday_hudong_success_precent}% / {qq_hudong_process_total}
- Logo识别:&nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_logodetect_process_total} / {qq_yesterday_logodetect_success_process} / {qq_yesterday_logodetect_success_precent}% / {qq_logodetect_process_total}
- 裸露检测: &nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_exposedetect_process_total} / {qq_yesterday_exposedetect_success_process} / {qq_yesterday_exposedetect_success_precent}% / {qq_exposedetect_process_total}
- 人脸检测: &nbsp;&nbsp;&nbsp;&nbsp;{qq_yesterday_facedetect_process_total} / {qq_yesterday_facedetect_success_process} / {qq_yesterday_facedetect_success_precent}% / {qq_facedetect_process_total}
-----------------------
**智康线下**:
 (昨日调用/成功次数/成功率/累计调用）
- ASR次数:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_offline_yesterday_process_total} / {zhikang_offline_yesterday_success_process} / {zhikang_offline_yesterday_success_precent}% / {zhikang_offline_process_total}
- ASR时长:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_offline_yesterday_duration_total} / - / - / {zhikang_offline_duration_total}
- 文本关键词:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_offline_yesterday_textdetect_process_total} / {zhikang_offline_yesterday_textdetect_success_process} / {zhikang_offline_yesterday_textdetect_success_precent}% / {zhikang_offline_textdetect_process_total}
- 多模态:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_offline_yesterday_multimode_process_total} / {zhikang_offline_yesterday_multimode_success_process} / {zhikang_offline_yesterday_multimode_success_precent}% / {zhikang_offline_yesterday_multimode_process_total}
- 人体检测:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_offline_yesterday_bodydetect_process_total} / {zhikang_offline_yesterday_bodydetect_success_process} / {zhikang_offline_yesterday_bodydetect_success_precent}% / {zhikang_offline_bodydetect_process_total}
-----------------------
**智康在线**:
 (昨日调用/成功次数/成功率/累计调用）
- ASR次数:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_online_yesterday_process_total} / {zhikang_online_yesterday_success_process} / {zhikang_online_yesterday_success_precent}% / {zhikang_online_process_total}
- ASR时长:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_online_yesterday_duration_total} / - / - / {zhikang_online_duration_total}
- 文本关键词:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_online_yesterday_textdetect_process_total} / {zhikang_online_yesterday_textdetect_success_process} / {zhikang_online_yesterday_textdetect_success_precent}% / {zhikang_online_textdetect_process_total}
- 多模态:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_online_yesterday_multimode_process_total} / {zhikang_online_yesterday_multimode_success_process} / {zhikang_online_yesterday_multimode_success_precent}% / {zhikang_online_multimode_process_total}
- 闲聊识别:&nbsp;&nbsp;&nbsp;&nbsp;{zhikang_online_yesterday_talkdetect_process_total} / {zhikang_online_yesterday_talkdetect_success_process} / {zhikang_online_yesterday_talkdetect_success_precent}% / {zhikang_online_talkdetect_process_total}
"""
    if qq_yesterday_process_total ==0:
        qq_yesterday_success_precent =0
    else:
        qq_yesterday_success_precent = int((qq_yesterday_success_process / qq_yesterday_process_total) * 100)

    if qq_yesterday_talkdetect_success_process == 0:
        qq_yesterday_talkdetect_success_precent = 0
    else:
        qq_yesterday_talkdetect_success_precent = int((qq_yesterday_talkdetect_success_process / qq_yesterday_talkdetect_process_total) * 100)

    if qq_yesterday_facedetect_success_process == 0:
        qq_yesterday_facedetect_success_precent = 0
    else:
        qq_yesterday_facedetect_success_precent = int(
            (qq_yesterday_facedetect_success_process / qq_yesterday_facedetect_process_total) * 100)

    if qq_yesterday_textdetect_success_process == 0:
        qq_yesterday_textdetect_success_precent = 0
    else:
        qq_yesterday_textdetect_success_precent = int((qq_yesterday_textdetect_success_process / qq_yesterday_textdetect_process_total) * 100)


    if qq_yesterday_exposedetect_success_process == 0:
        qq_yesterday_exposedetect_success_precent = 0
    else:
        qq_yesterday_exposedetect_success_precent = int((qq_yesterday_exposedetect_success_process / qq_yesterday_exposedetect_process_total) * 100)


    if qq_yesterday_logodetect_success_process == 0:
        qq_yesterday_logodetect_success_precent = 0
    else:
        qq_yesterday_logodetect_success_precent = int((qq_yesterday_logodetect_success_process / qq_yesterday_logodetect_process_total) * 100)


    if qq_yesterday_multimode_success_process == 0:
        qq_yesterday_multimode_success_precent = 0
    else:
        qq_yesterday_multimode_success_precent = int((qq_yesterday_multimode_success_process / qq_yesterday_multimode_process_total) * 100)

    if qq_yesterday_hudong_success_process == 0:
        qq_yesterday_hudong_success_precent = 0
    else:
        qq_yesterday_hudong_success_precent = int((qq_yesterday_hudong_success_process / qq_yesterday_hudong_process_total) * 100)

    if zhikang_offline_yesterday_success_process == 0:
        zhikang_offline_yesterday_success_precent=0
    else:
        zhikang_offline_yesterday_success_precent = int((zhikang_offline_yesterday_success_process / zhikang_offline_yesterday_process_total) * 100)

    if zhikang_online_yesterday_success_process==0:
        zhikang_online_yesterday_success_precent=0
    else:
        zhikang_online_yesterday_success_precent = int((zhikang_online_yesterday_success_process / zhikang_online_yesterday_process_total) * 100)

    if zhikang_online_yesterday_bodydetect_success_process==0:
        zhikang_online_yesterday_bodydetect_success_precent=0
    else:
        zhikang_online_yesterday_bodydetect_success_precent = int((zhikang_online_yesterday_bodydetect_success_process / zhikang_online_yesterday_bodydetect_process_total) * 100)

    if zhikang_online_yesterday_textdetect_success_process == 0:
        zhikang_online_yesterday_textdetect_success_precent = 0
    else:
      zhikang_online_yesterday_textdetect_success_precent = int((zhikang_online_yesterday_textdetect_success_process / zhikang_online_yesterday_textdetect_process_total) * 100)

    if zhikang_online_yesterday_multimode_success_process == 0:
        zhikang_online_yesterday_multimode_success_precent = 0
    else:
       zhikang_online_yesterday_multimode_success_precent = int((zhikang_online_yesterday_multimode_success_process / zhikang_online_yesterday_multimode_process_total) * 100)


    if zhikang_offline_yesterday_bodydetect_success_process==0:
        zhikang_offline_yesterday_bodydetect_success_precent=0
    else:
        zhikang_offline_yesterday_bodydetect_success_precent = int((zhikang_offline_yesterday_bodydetect_success_process / zhikang_offline_yesterday_bodydetect_process_total) * 100)

    if zhikang_offline_yesterday_textdetect_success_process == 0:
        zhikang_offline_yesterday_textdetect_success_precent = 0
    else:
       zhikang_offline_yesterday_textdetect_success_precent = int((zhikang_offline_yesterday_textdetect_success_process / zhikang_offline_yesterday_textdetect_process_total) * 100)

    if zhikang_offline_yesterday_multimode_success_process == 0:
        zhikang_offline_yesterday_multimode_success_precent = 0
    else:
        zhikang_offline_yesterday_multimode_success_precent = int((zhikang_offline_yesterday_multimode_success_process / zhikang_offline_yesterday_multimode_process_total) * 100)

    if zhikang_online_yesterday_talkdetect_success_process== 0:
        zhikang_online_yesterday_talkdetect_success_precent = 0
    else:
        zhikang_online_yesterday_talkdetect_success_precent = int((zhikang_online_yesterday_talkdetect_success_process / zhikang_online_yesterday_talkdetect_process_total) * 100)

    content = template.format(
        date=today.strftime("%Y-%m-%d"),
        project_name=project_name,

        qq_hudong_process_total=qq_hudong_process_total,
        qq_yesterday_hudong_success_process=qq_yesterday_hudong_success_process,
        qq_yesterday_hudong_process_total=qq_yesterday_hudong_process_total,
        qq_yesterday_hudong_success_precent=qq_yesterday_hudong_success_precent,
        qq_yesterday_process_total=qq_yesterday_process_total,
        qq_yesterday_success_process=qq_yesterday_success_process,
        qq_yesterday_success_precent=qq_yesterday_success_precent,
        qq_yesterday_duration_total=int(qq_yesterday_duration_total/3600),
        qq_process_total=qq_process_total,
        qq_duration_total=int(qq_duration_total/3600),
        qq_yesterday_multimode_success_process=qq_yesterday_multimode_success_process,
        qq_yesterday_multimode_process_total=qq_yesterday_multimode_process_total,
        qq_multimode_process_total=qq_multimode_process_total,
        qq_yesterday_multimode_success_precent=qq_yesterday_multimode_success_precent,
        qq_yesterday_talkdetect_process_total=qq_yesterday_talkdetect_process_total,
        qq_yesterday_talkdetect_success_process=qq_yesterday_talkdetect_success_process,
        qq_talkdetect_process_total=qq_talkdetect_process_total,
        qq_yesterday_talkdetect_success_precent=qq_yesterday_talkdetect_success_precent,
        qq_yesterday_logodetect_success_precent=qq_yesterday_logodetect_success_precent,
        qq_yesterday_logodetect_success_process=qq_yesterday_logodetect_success_process,
        qq_logodetect_process_total=qq_logodetect_process_total,
        qq_yesterday_logodetect_process_total=qq_yesterday_logodetect_process_total,
        qq_exposedetect_process_total=qq_exposedetect_process_total,
        qq_yesterday_exposedetect_success_precent=qq_yesterday_exposedetect_success_precent,
        qq_yesterday_exposedetect_process_total=qq_yesterday_exposedetect_process_total,
        qq_yesterday_exposedetect_success_process=qq_yesterday_exposedetect_success_process,

        qq_textdetect_process_total=qq_textdetect_process_total,
        qq_yesterday_textdetect_process_total = qq_yesterday_textdetect_process_total,
        qq_yesterday_textdetect_success_process = qq_yesterday_textdetect_success_process,
        qq_yesterday_textdetect_success_precent = qq_yesterday_textdetect_success_precent,

        qq_facedetect_process_total=qq_facedetect_process_total,
        qq_yesterday_facedetect_process_total=qq_yesterday_facedetect_process_total,
        qq_yesterday_facedetect_success_process=qq_yesterday_facedetect_success_process,
        qq_yesterday_facedetect_success_precent=qq_yesterday_facedetect_success_precent,

        zhikang_offline_multimode_process_total=zhikang_offline_multimode_process_total,
        zhikang_offline_process_total=zhikang_offline_process_total,
        zhikang_offline_yesterday_process_total=zhikang_offline_yesterday_process_total,
        zhikang_offline_yesterday_success_process=zhikang_offline_yesterday_success_process,
        zhikang_offline_yesterday_success_precent=zhikang_offline_yesterday_success_precent,
        zhikang_offline_yesterday_duration_total=int(zhikang_offline_yesterday_duration_total/3600),
        zhikang_offline_yesterday_bodydetect_process_total=zhikang_offline_yesterday_bodydetect_process_total,
        zhikang_offline_yesterday_bodydetect_success_process=zhikang_offline_yesterday_bodydetect_success_process,
        zhikang_offline_yesterday_bodydetect_success_precent=zhikang_offline_yesterday_bodydetect_success_precent,
        zhikang_offline_yesterday_textdetect_success_process=zhikang_offline_yesterday_textdetect_success_process,
        zhikang_offline_bodydetect_process_total=zhikang_offline_bodydetect_process_total,
        zhikang_offline_yesterday_textdetect_process_total=zhikang_offline_yesterday_textdetect_process_total,
        zhikang_offline_yesterday_textdetect_success_precent=zhikang_offline_yesterday_textdetect_success_precent,
        zhikang_offline_textdetect_process_total=zhikang_offline_textdetect_process_total,
        zhikang_offline_yesterday_multimode_success_process=zhikang_offline_yesterday_multimode_success_process,
        zhikang_offline_yesterday_multimode_success_precent=zhikang_offline_yesterday_multimode_success_precent,
        zhikang_offline_yesterday_multimode_process_total= zhikang_offline_yesterday_multimode_process_total,

        zhikang_offline_duration_total=int(zhikang_offline_duration_total/3600),

        zhikang_online_yesterday_talkdetect_success_precent=zhikang_online_yesterday_talkdetect_success_precent,
        zhikang_online_yesterday_talkdetect_success_process=zhikang_online_yesterday_talkdetect_success_process,
        zhikang_online_yesterday_talkdetect_process_total=zhikang_online_yesterday_talkdetect_process_total,
        zhikang_online_talkdetect_process_total=zhikang_online_talkdetect_process_total,
        zhikang_online_multimode_process_total=zhikang_online_multimode_process_total,
        zhikang_online_process_total=zhikang_online_process_total,
        zhikang_online_yesterday_process_total=zhikang_online_yesterday_process_total,
        zhikang_online_yesterday_success_process=zhikang_online_yesterday_success_process,
        zhikang_online_yesterday_success_precent=zhikang_online_yesterday_success_precent,
        zhikang_online_yesterday_duration_total=int(zhikang_online_yesterday_duration_total/3600),
        zhikang_online_duration_total=int(zhikang_online_duration_total/3600),
        zhikang_online_yesterday_bodydetect_process_total=zhikang_online_yesterday_bodydetect_process_total,
        zhikang_online_bodydetect_process_total=zhikang_online_bodydetect_process_total,
        zhikang_online_yesterday_bodydetect_success_process=zhikang_online_yesterday_bodydetect_success_process,
        zhikang_online_yesterday_bodydetect_success_precent=zhikang_online_yesterday_bodydetect_success_precent,
        zhikang_online_yesterday_textdetect_process_total=zhikang_online_yesterday_textdetect_process_total,
        zhikang_online_yesterday_textdetect_success_process=zhikang_online_yesterday_textdetect_success_process,
        zhikang_online_yesterday_textdetect_success_precent=zhikang_online_yesterday_textdetect_success_precent,
        zhikang_online_textdetect_process_total=zhikang_online_textdetect_process_total,
        zhikang_online_yesterday_multimode_success_process=zhikang_online_yesterday_multimode_success_process,
        zhikang_online_yesterday_multimode_success_precent=zhikang_online_yesterday_multimode_success_precent,

        zhikang_online_yesterday_multimode_process_total=zhikang_online_yesterday_multimode_process_total,

        qq_test_yesterday_process_total=qq_test_yesterday_process_total,
        qq_test_yesterday_duration_total=int(qq_test_yesterday_duration_total/3600),
        qq_test_process_total=qq_test_process_total,
        qq_test_duration_total=int(qq_test_duration_total/3600)

    )

    print(content)


    obj = DingTalk(
        # 'https://oapi.dingtalk.com/robot/send?access_token=0d037b1ed7f8840885d534d1084ec4bab3f12beb448f9a355ecca15e1a5e8fa7')  # 测试
        'https://oapi.dingtalk.com/robot/send?access_token=13255d864fb46e26114672c88277dda34a6f1bc9678e9850a388393ff9982496')  # prod
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营日报".format(date=yesterday.strftime("%Y-%m-%d")))
    # 发送到总群
    obj = DingTalk(
        'https://oapi.dingtalk.com/robot/send?access_token=c988c827d87c7742f945ad0417f6f77110863420bd445e45a5b0825f9a2b0729')
    obj.send_msg(content, [], at_all=True, msg_type="markdown",
                 title="{date} 运营分析日报".format(date=yesterday.strftime("%Y-%m-%d")))


if __name__ == "__main__":
    send_daily_report()