import datetime
import time
import requests
import pymysql
import re
import os
import tempfile
from jinja2 import Template
from elasticsearch import Elasticsearch

class busizObj:

    def __init__(self):
        name=''
        online_yesterday=0
        offline_yesterday=0
        online_total=0
        offline_total=0

    def set_name(self,name):
        self.name=name

    def set_online_yesterday(self,online_yesterday):
        self.online_yesterday=online_yesterday

    def set_offline_yesterday(self,offline_yesterday):
        self.offline_yesterday=offline_yesterday

    def set_online_total(self,online_total):
        self.online_total=online_total

    def set_offline_total(self,offline_total):
        self.offline_total=offline_total

class busizReport:

    def __init__(self,date,projectname):
        self.date= date
        self.projectname=projectname
        self.offline_total_call=0
        self.offline_yesterday_total=0
        self.online_total_call=0
        self.online_yesterday_total=0
        self.busizGroups={}

class Properties:

    def __init__(self, file_name):
        self.file_name = file_name
        self.properties = {}
        try:
            fopen = open(self.file_name, 'r')
            for line in fopen:
                line = line.strip()
                if line.find('=') > 0 and not line.startswith('#'):
                    strs = line.split('=')
                    self.properties[strs[0].strip()] = strs[1].strip()
        except Exception as e:
            raise e
        else:
            fopen.close()

    def has_key(self, key):
        if key in self.properties:
            return True
        return False

    def get(self, key, default_value=''):
        if key in self.properties:
            return self.properties[key]
        return default_value

    def put(self, key, value):
        self.properties[key] = value
        replace_property(self.file_name, key + '=.*', key + '=' + value, True)

def parse(file_name):
    return Properties(file_name)


def replace_property(file_name, from_regex, to_str, append_on_not_exists=True):
    file = tempfile.TemporaryFile()         #创建临时文件
    if os.path.exists(file_name):
        r_open = open(file_name,'r')
        pattern = re.compile(r''+from_regex)
        found = None

        for line in r_open: #读取原文件
            if pattern.search(line) and not line.strip().startswith('#'):
                found = True
                line = re.sub(from_regex, to_str, line)
            file.write(line.encode())   #写入临时文件
        if not found and append_on_not_exists:
            file.write('\n' + to_str.encode())
        r_open.close()
        file.seek(0)

        content = file.read()  #读取临时文件中的所有内容

        if os.path.exists(file_name):
            os.remove(file_name)

        w_open = open(file_name,'w')
        w_open.write(str(content,encoding='gbk'))   #将临时文件中的内容写入原文件
        w_open.close()

        file.close()  #关闭临时文件，同时也会自动删掉临时文件
    else:
        print("file %s not found" % file_name)


class DingTalk:
    def __init__(self, url):
        """
        :param content: str
        :param url: str
        :param at_mobiles: list
        :param msg_type: str
        :param at_all: bool
        """
        self.url = url

    def send_msg(self, content, at_mobiles, msg_type='text', at_all=False, title=''):
        if msg_type == 'text':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'text': {'content': content}
            }
            return requests.post(self.url, json=data)
        if msg_type == 'markdown':
            data = {
                "msgtype": msg_type,
                "at": {
                    # "atMobiles": at_mobiles,
                    "isAtAll": at_all
                },
                'markdown': {'title': title, 'text': content}
            }
            print(title, content)
            return requests.post(self.url, json=data)


def send_daily_report():
    # 核心逻辑
    # 1。查询运行时的业务记录
    # 2。把业务数据信息写入mysql数据库中，并加入时间戳-- 目前采用的是临时方案，写入properties文件记录当前总共的请求次数
    # 3。根据时间戳的方式获取从特定年份累计的的业务数据调用良
    # 4。根据日报看板格式展示内容

    #用于建立accountID 与 用户实际名称的对应关系
    #acountid_appkey_map={"TAL_xuedi":"3", "":"8"}
    #acountid_appkey_map = {"3": "TAL_xuedi", "18": "TAL_weilaimofaxiao"}
    acountid_appkey_map = {"3": "TAL_xuedi", "18": "TAL_weilaimofaxiao"}

    offline_available_appkey={"TAL_0001":"学而思-未来宝盒","TAL_0002":"未来魔法校-双师英语"}
    #online_available_appkey_bizname={"4436695155098624":"未来魔法校-双师英语","4446913917518848":"出版中心"}
    online_available_appkey_bizname = {"4436695155098624": "未来魔法校-双师英语"}
    online_offline_appkey_mapping={}

    today = datetime.date.today()  # 获取当前日期
    today_timestamp = int(time.mktime(today.timetuple())) + 28800
    print(today_timestamp)
    yesterday = (today - datetime.timedelta(days=1))  #获取昨天的日期
    print(yesterday)
    yesterday_timestamp = int(time.mktime(yesterday.timetuple())) + 28800
    print(yesterday_timestamp)

    project_name="语音评测"
    date = today.strftime("%Y-%m-%d")

    # #存储语音评测线下累计调用量的临时文件
    # contentsRecord = parse("./test.properties")

    #记录全部日报数据的对象
    _busizReport = busizReport(date, project_name)

    #ES上的index,用于查询语音评测线上调用量
    index_name = "api-return-output-prod*"

    # 线上调用统计--信息来自Paas ES
    es = Elasticsearch([{'host': '221.122.130.6', 'port': 9200}], http_auth=('se', 'se@paas_prod'))

    # aggratiation appKey to get all business client process totall
    _query_aggs_appId_contains = {
	    "size": 0,
        "aggs": {
            "apiId": {
                "terms": {
                    "field": "apiId.keyword",
                    "size": 100
                },
                "aggs": {
                    "appKey": {
                        "terms": {
                            "field": "appKey.keyword",
                             "size": 100
                        }
                    }
                }
            }
        }
    }

    _query_yesterday_to_today_contains = {
        "size": 0,
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    },
                    {
                        "range": {
                            "@timestamp": {
                                "gte": int(yesterday_timestamp) * 1000,
                                "lte": int(today_timestamp) * 1000,
                                "format": "epoch_millis"
                            }
                        }
                    }
                ]
            }
        },
        "aggs": {
            "apiId": {
                "terms": {
                    "field": "apiId.keyword",
                    "size": 100
                },
                "aggs": {
                    "appKey": {
                        "terms": {
                            "field": "appKey.keyword",
                            "size": 100
                        }
                    }
                }
            }
        }
    }

    totals_by_appId=es.search(index=index_name, body=_query_aggs_appId_contains)['aggregations']["apiId"]["buckets"]
    #print(totals_by_appId)

    yesterday_by_appId=es.search(index=index_name, body=_query_yesterday_to_today_contains)['aggregations']["apiId"]["buckets"]
    #print(yesterday_by_appId)

    # handle special case
    if len(yesterday_by_appId) != 0:
        for item in yesterday_by_appId:

            if item['key'] == "23":

                for sub_item in item['appKey']['buckets']:

                    if sub_item['key'] in online_available_appkey_bizname.keys():

                        if online_available_appkey_bizname[sub_item['key']] in _busizReport.busizGroups:

                            _busiz = _busizReport.busizGroups[online_available_appkey_bizname[sub_item['key']]]
                        else:
                            _busiz = busizObj()

                        _busiz.set_name(online_available_appkey_bizname[sub_item['key']])
                        _busiz.set_online_yesterday(sub_item['doc_count'])
                        _busizReport.busizGroups[online_available_appkey_bizname[sub_item['key']]] = _busiz
                        # 增加昨日在线调用总量
                        _busizReport.online_yesterday_total+=_busiz.online_yesterday


    for item in totals_by_appId:

         if item['key'] == "23":
             for sub_item in item['appKey']['buckets']:

                 if sub_item['key'] in online_available_appkey_bizname.keys():

                      #print("find key "+sub_item['key']+" in accountid_appkey_map")

                      if online_available_appkey_bizname[sub_item['key']] in _busizReport.busizGroups:

                          _busiz = _busizReport.busizGroups[online_available_appkey_bizname[sub_item['key']]]
                      else:
                          #print("create a new busiz object for: "+ acountid_appkey_map[sub_item['key']])
                          _busiz = busizObj()
                          _busiz.set_online_yesterday(0)

                      _busiz.set_name(online_available_appkey_bizname[sub_item['key']])
                      _busiz.set_online_total(sub_item['doc_count'])
                      _busiz.set_offline_total(0)
                      _busiz.set_offline_yesterday(0)
                      _busizReport.busizGroups[online_available_appkey_bizname[sub_item['key']]]=_busiz
                      #print(_busizReport.busizGroups)
                      #增加在线调用总量
                      _busizReport.online_total_call+= _busiz.online_total

    # 线下调用总量统计--信息来自mysql
    conn = pymysql.connect(host="rm-2zegvd17buc6689oe8o.mysql.rds.aliyuncs.com", user ="root", password ="nTCgKRNwaSs8Waaeb5ZJbc3wTPt5lLsA", database ="speech_eval")
    cursor = conn.cursor()

    sql = 'select appkey, sum(eval_count) as call_num  from eval_count GROUP BY appkey;'

    cursor.execute(sql)

    results = cursor.fetchall()

    cursor = conn.cursor()

    sql_yesterday = "select appkey, sum(eval_count) as call_num  from eval_count where eval_date='" + str(yesterday) + "' GROUP BY appkey;"

    cursor.execute(sql_yesterday)

    yesterday_results = cursor.fetchall()

    cursor.close()
    conn.close()

    for row in results:

        _appkey= row[0]
        _callnum= row[1]

        if _appkey in offline_available_appkey.keys():

            if offline_available_appkey[_appkey] in _busizReport.busizGroups:
              #print(_appkey+" in buzieReportGroup....")
              _busiz = _busizReport.busizGroups[offline_available_appkey[_appkey]]
            else:
              #print(_appkey + " create new one in buzieReportGroup....")
              _busiz = busizObj()
              _busiz.set_online_total(0)
              _busiz.set_online_yesterday(0)

            _busiz.set_name(offline_available_appkey[_appkey])

            _busiz.set_offline_total(_callnum)

            offline_yesterday = 0
            #设置昨日调用量的默认值，后续进行更新
            _busiz.set_offline_yesterday(offline_yesterday)

            # 增加离线调用总量
            _busizReport.offline_total_call+=_callnum

            _busizReport.busizGroups[offline_available_appkey[_appkey]]=_busiz

    for row in yesterday_results:

        _appkey = row[0]
        _callnum = row[1]

        if _appkey in offline_available_appkey.keys():
           #因为先算的总调用量，所以一定存在对应业务线的纪录
           _busiz = _busizReport.busizGroups[offline_available_appkey[_appkey]]

           #设置业务线离线调用量
           _busiz.set_offline_yesterday(_callnum)

           #累计所有业务的昨日离线调用量

           _busizReport.offline_yesterday_total+=_callnum

           _busizReport.busizGroups[offline_available_appkey[_appkey]] = _busiz

    template = """### {{_busizReport.date }} {{_busizReport.projectname }}运营日报  
 ** 语音评测调用总量 **:   
 - 昨日在线调用次数： {{ _busizReport.online_yesterday_total }}
 - 累计在线调用次数： {{ _busizReport.online_total_call }}
 - 昨日离线调用次数： {{ _busizReport.offline_yesterday_total }}
 - 累计离线调用次数： {{ _busizReport.offline_total_call }}
-----------------------
{%- for busiz in _busizReport.busizGroups.values() %}
** {{ busiz.name }} **:
- 昨日在线调用次数：{{ busiz.online_yesterday }}
- 昨日离线调用次数：{{ busiz.offline_yesterday }}
- 累计在线调用次数: {{ busiz.online_total }}
- 累计离线调用次数: {{ busiz.offline_total }}
-----------------------
{% endfor %}
"""
    result = Template(source=template).render(_busizReport=_busizReport)

    print(result)
    obj = DingTalk(
    'https://oapi.dingtalk.com/robot/send?access_token=bc1587fd4f681058f050c6328479edfe54f8433eecbbcdcd62d3244d1333e2a4')  # 测试
    obj.send_msg(result, [], at_all=True, msg_type="markdown",
                 title="{date} 运营日报".format(date=today.strftime("%Y-%m-%d")))

    #Insert data into dailyreport database in evalvoice_report table
    conn = pymysql.connect(host="221.122.129.44", user="dailyreport",
                           password="1rmuK7TISiNnw", database="dailyreport")
    cursor = conn.cursor()

    for busiz in _busizReport.busizGroups.values():

          _yesterday_total= busiz.online_yesterday+busiz.offline_yesterday

          sql = "INSERT INTO evalvoice_report(biz_name,date,online_call,offline_call,total_call) VALUES('"+busiz.name+"','"+str(yesterday)+"',"+str(busiz.online_yesterday)+","+str(busiz.offline_yesterday)+","+str(busiz.online_yesterday+busiz.offline_yesterday)+");"
          #sql = "insert into evalvoice_report(biz_name,date,online_call,offline_call,total_call) values('"+busiz.name+"','2019-06-27',"+str(busiz.online_yesterday)+","+str(busiz.offline_yesterday)+","+str(busiz.online_yesterday+busiz.offline_yesterday)+");"

          print(sql)
          try:
              cursor.execute(sql)
              conn.commit()
          except:
              conn.rollback()
              print("insert failed!")

    conn.close()


if __name__ == "__main__":
    send_daily_report()