from datetime import datetime,timedelta
from concurrent.futures import ThreadPoolExecutor

import gitlab

from .models import GitlabRepo, CommitInfo, CommitSummary, ZendaoBugSummary
from utils.zendao import ZentaoBugWeight, ZentaoBugCounter


def store_commit_info(project_obj, commit_obj, gitlab_repo_obj):
    """
    存储commit信息，并返回本次commit的改动行数
    :param commit_obj: commit对象
    :return:
    """
    commit_obj = project_obj.commits.get(commit_obj.id)
    commit_info = CommitInfo.objects.filter(commit_id=commit_obj.id).first()
    if not commit_info:
        commit_info = CommitInfo()
        commit_info.commit_id = commit_obj.id
        try:
            commit_info.commit_time = datetime.strptime(commit_obj.committed_date, "%Y-%m-%dT%H:%M:%S.%fZ")
        except ValueError:
            try:
                commit_info.commit_time = datetime.strptime(commit_obj.committed_date, "%Y-%m-%dT%H:%M:%S.%f+00:00")
            except ValueError:
                commit_info.commit_time = datetime.strptime(commit_obj.committed_date, "%Y-%m-%dT%H:%M:%S.%f-08:00")
        commit_info.change_lines = commit_obj.stats['total']
        commit_info.gitlab_repo = gitlab_repo_obj
        commit_info.save()
    return commit_obj.stats['total']


def gitlab_repo_analysis():
    now = datetime.now()
    today = datetime(now.year, now.month, now.day, 0, 0, 0)

    for i in range(0, 5):
        # 本周
        this_week_start = today - timedelta(days=today.weekday() + 7*i)  # 周一0点
        if i == 0:
            this_week_end = today + timedelta(days=7 - today.weekday())  # 周日24点
        else:
            this_week_end = today - timedelta(days=today.weekday() + 7*(i -1))  # 周日24点

        print(this_week_start, this_week_end)

        # gitlab_repo_list = GitlabRepo.objects.all()
        project_info_list = GitlabRepo.objects.values('project_num', 'project_name')
        project_list = []
        for project_info in project_info_list:
            if project_info not in project_list:
                project_list.append(project_info)
        print(project_list)
        gitlab_repo = None
        for project in project_list:
            commit_change_total = 0
            commit_summary = None
            gitlab_repos = GitlabRepo.objects.filter(project_num=project['project_num'], project_name=project['project_name'])
            for gitlab_repo in gitlab_repos:
                # 连接gitlab
                try:
                    gl = gitlab.Gitlab(gitlab_repo.url, private_token=gitlab_repo.private_token)
                    gl.auth()
                except Exception as e:
                    print(gitlab_repo.url, gitlab_repo.private_token, gitlab_repo.path)
                    continue

                # 获取某个项目的信息

                try:
                    project = gl.projects.get(gitlab_repo.path)
                except Exception as e:
                    print(gitlab_repo.path)
                    continue

                # 获取这一周所有的commit
                commits = project.commits.list(  # 从since时间点 至until时间点
                    since=this_week_start,
                    until=this_week_end,
                    ref_name=gitlab_repo.branch
                )

                sum_list = []

                for commit in commits:
                    res = store_commit_info(project, commit, gitlab_repo)
                    sum_list.append(res)

                commit_change_total += sum(sum_list)  # 所有commit改变的总行数
                # print(commit_change_total, sum_list)

            if gitlab_repo:
                # CommitSummary入库
                commit_summary = CommitSummary.objects.filter(date_point=this_week_start, gitlab_repo=gitlab_repo).first()
                if not commit_summary:
                    commit_summary = CommitSummary()
                    commit_summary.gitlab_repo = gitlab_repo
                    commit_summary.date_point = this_week_start
                commit_summary.from_date = this_week_start
                commit_summary.to_date = this_week_end
                commit_summary.total = commit_change_total
            if commit_summary and gitlab_repo:
                # 计算缺陷密度
                zentao_bug_weight = ZentaoBugWeight('http://xxxx.xxxx.xxx', 'xxxx', 'xxxxx', gitlab_repo.project_num)
                data = zentao_bug_weight.get_data()
                content, project = data
                try:
                    bug_weight = zentao_bug_weight.parser(content, project, gitlab_repo.project_name, this_week_start.strftime("%Y-%m-%d"), this_week_end.strftime("%Y-%m-%d"))  # 起止日期格式 YYYY-mm-dd
                except Exception as e:
                    print("ERROR",gitlab_repo.project_name, gitlab_repo.project_num)
                    continue
                if commit_change_total == 0:
                    commit_summary_list = CommitSummary.objects.filter(gitlab_repo=gitlab_repo).order_by("-date_point")
                    for commit_summary_obj in commit_summary_list:
                        if commit_summary_obj.total != 0:
                            commit_change_total = commit_summary_obj.total
                            break
                    else:
                        commit_change_total = 1
                commit_summary.defect_density = bug_weight / commit_change_total * 1000
                # print(commit_summary.defect_density, gitlab_repo.project_name)
                commit_summary.save()
                print(commit_change_total, gitlab_repo.project_name)

                # Bug分类入库
                zendao_bug_counter = ZentaoBugCounter('http://xxx.xxx.xxx', 'xxxx', 'xxxx', gitlab_repo.project_num)
                data = zendao_bug_counter.get_data()
                if not data:
                    return None
                content, project = data
                bug_summary = zendao_bug_counter.parser(content, project, gitlab_repo.project_name, this_week_start.strftime("%Y-%m-%d"), this_week_end.strftime("%Y-%m-%d"))
                # print(bug_summary)
                zendao_bug_summary = ZendaoBugSummary.objects.filter(gitlab_repo=gitlab_repo, date_point=this_week_start).first()
                if not zendao_bug_summary:
                    zendao_bug_summary = ZendaoBugSummary()
                    zendao_bug_summary.date_point = this_week_start
                    zendao_bug_summary.gitlab_repo = gitlab_repo

                zendao_bug_summary.last = bug_summary['last']
                zendao_bug_summary.online = bug_summary['online']
                zendao_bug_summary.codeerror = bug_summary['codeerror']
                zendao_bug_summary.interface = bug_summary['interface']
                zendao_bug_summary.config = bug_summary['config']
                zendao_bug_summary.install = bug_summary['install']
                zendao_bug_summary.security = bug_summary['security']
                zendao_bug_summary.performance = bug_summary['performance']
                zendao_bug_summary.standard = bug_summary['standard']
                zendao_bug_summary.automation = bug_summary['automation']
                zendao_bug_summary.designdefect = bug_summary['designdefect']
                zendao_bug_summary.codeimprovement = bug_summary['codeimprovement']
                zendao_bug_summary.others = bug_summary['others']
                zendao_bug_summary.requrement = bug_summary['requrement']
                zendao_bug_summary.prodissue = bug_summary['prodissue']
                zendao_bug_summary.prodissue1 = bug_summary['prodissue1']
                zendao_bug_summary.prodissue2 = bug_summary['prodissue2']
                zendao_bug_summary.prodissue3 = bug_summary['prodissue3']
                zendao_bug_summary.prodissue4 = bug_summary['prodissue4']
                zendao_bug_summary.reopen = bug_summary['reopen']
                zendao_bug_summary.autodetected = bug_summary['autodetected']
                zendao_bug_summary.envissue = bug_summary['envissue']
                zendao_bug_summary.total = bug_summary['total']
                zendao_bug_summary.save()
