"""devops_nav URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
import xadmin

from django.urls import path
from apps.nav.views import IndexView, ElkView, DashboardView, GrafanaView
from apps.elastalert.views import AlertInfoView

from apscheduler.scheduler import Scheduler
from apps.ci_dashboard import tasks
from apps.code_dashboard import tasks2 as gitlab_task
from apps.elastalert import tasks as elastalert_task

from utils.daily_report import dolphin, godeye, ikkyyu, godeye_test, ges, godeye_asr, evalvoice
from utils.register_remind import onwork, offwork

from utils.daily_get import ikkyyu as get_ikkyyu_daily_data
from utils.daily_get import ikkyyu_new
################# 路由 #################
urlpatterns = [
    path('xadmin/', xadmin.site.urls),     # xadmin 后台管理系统
    path('', DashboardView.as_view(), name="dashboard"),       # 首页
    path('elk/', GrafanaView.as_view(), name="elk"),            # elk看板相关
    path('repo_analysis/', gitlab_task.gitlab_repo_analysis),   
    path('elastalert/', AlertInfoView.as_view(), name="elastalert"),   # elastalert相关
]
################# 路由 #################

################# 定时任务 #################

sched = Scheduler()


#@sched.interval_schedule(seconds=6tlab_repo_analysis()0)
#def gitlab_repo_analysis():  # 代码缺陷密度分析
#    gitlab_task.gitlab_repo_analysis('20180101','20180105')
#gitlab_repo_analysis()
#
# @sched.interval_schedule(seconds=7200)
# def get_jenkins_job_task():  # Jenkins构建分析
#     tasks.get_jenkins_job()  # 获取Jenkins job的构建状态
#     try:
#         tasks.get_jenkins_build_count()   # 获取Jenkins job的日构建次数
#     except Exception as e:
#         print(e)


sched.start()  # 启动
################# 定时任务 #################
